---
name: positions-monitor
description: "Intraday watchdog — stop buffer, time-invalidation, earnings, catalyst, thesis variables, portfolio heat, correlation gate. Always writes rich HTML dashboard: background, thesis, S/T/C/R scores, invalidation checklist per position. Writes MD only on CRITICAL/HIGH flags. Use for 'check positions', 'monitor book', 'are my stops OK', 'portfolio heat', 'positions dashboard', 'what do I have on'."
model: sonnet
allowed-tools: Bash(python3 *) Read Write Edit WebSearch Grep Glob
---

# Positions Monitor — Live Book Watchdog

**Primary output (always):** `{YYYY-MM-DD}/positions-monitor-{YYYY-MM-DD}.html`
**Secondary output (CRITICAL/HIGH flags only):** `{YYYY-MM-DD}/positions-monitor-{YYYY-MM-DD}.md`

Create folder first: `python3 -c "import os; os.makedirs('{YYYY-MM-DD}', exist_ok=True)"`

## Reads (and nothing else)
1. `framework/Memory.md` — §1 Account NAV, §2 Open Positions (entries, stops, ATRs, theses, tranches, time-stops), §5 Watchlist (pending positions, Sum scores, catalysts)
2. `pipeline/.pipeline-status.json` (if present)
3. Latest `*/us-close-snapshot-*.md` (date-folder; falls back to root) — current prices + regime delta
4. `{today}/slack-digest-{today}.md` if present. Invoke `/slack-ingest` if missing — cloud agent fires 4×/day.
5. `scripts/gen_positions_html.py` — read once to understand PER-RUN DATA structure before editing.

Do NOT read framework/Methodology Prompt.md, framework/Risk Rules.md, cores, framework/Data Sources.md. Overrides startup protocol.

## Flag Panel

| Flag | Condition | Severity |
|---|---|---|
| F1 stop_buffer | distance_to_stop / ATR_14d < 2.0 | HIGH |
| F2 stop_hit | price ≤ stop (long) or ≥ stop (short) | CRITICAL |
| F3 time_inv | days_until_inv_date ≤ 7 | MED |
| F4 earnings | days_until_earnings ≤ 2 | HIGH |
| F5 catalyst | abs(days_until_catalyst) ≤ 1 | HIGH |
| F6 data | unable to price within 2 tries | MED |
| F7 ah_move | abs(overnight_pct) ≥ 3% (stock) or 1% (index/commodity) | HIGH |
| F8 thesis_var | thesis-invalidation variable breached kill level | CRITICAL |
| F9 portfolio_heat | total \|entry−stop\|/NAV > 6% | HIGH |
| F10 correlation_gate | pairwise \|ρ_60d\| > 0.7 | MED |
| F11 cot_crowding | commodity: COT spec net longs > 2σ above 52w avg (search "COT report {commodity} latest") | MED |
| F12 vol_band | cloud agent flagged vol-band-violation in digest `[POSITION-ALERT]` | HIGH |
| F13 cloud_alert | any other `[POSITION-ALERT]` from digest not covered by F1–F12 | MED |

## Workflow

**Step 1 — Inventory**
Read `framework/Memory.md §2`. Extract per open position: ID, asset, side, avg entry (all tranche fills), stop, ATR, time-stop, Sum score, thesis, invalidation conditions. Read §5 for pending positions.

**Step 2 — Slack digest**
Check `{today}/slack-digest-{today}.md`. Invoke `/slack-ingest` if missing. Parse all `[POSITION-ALERT]` lines.

**Step 3 — Price pull**
Use latest `us-close-snapshot-*.md` as baseline. WebSearch any ticker missing from snapshot. Compute unrealized_pct = (live_f − entry_f) / entry_f × 100 for each open position.

**Step 4 — Compute all 13 flags**
- F1: (live_f − stop_f) / ATR_14d < 2.0
- F2: live_f ≤ stop_f (long)
- F3: days to time_stop ≤ 7
- F4/F5: earnings or catalyst dates vs. open + pending positions
- F6: price missing after 2 attempts
- F7: abs change vs. prev close ≥ 3% (stock) / 1% (index/commodity)
- F8: each invalidation variable from Memory.md §2 — flag if at/beyond kill level
- F9: sum \|entry−stop\| / PORT_NAV > 6%
- F10: same-direction positions sharing primary macro driver
- F11: WebSearch "COT report {commodity} latest" for commodity positions
- F12/F13: from slack digest POSITION-ALERT entries

**Step 5 — Re-assess S/T/C/R scores (current state)**
For each open and pending position, re-evaluate each score leg based on today's data — not entry state:
- **S**: overlay gate still ON? structural variable (DXY, credit, SMA) shifted?
- **T**: momentum still intact? price action since entry changed 1m/3m trend?
- **C**: catalyst passed (what outcome)? new catalyst now relevant?
- **R**: V027 current z-score? crowding changed? dealer gamma shifted?

Write one rationale sentence per leg capturing today's reading and mechanism.

**Step 6 — Generate HTML dashboard**

6a. Edit `scripts/gen_positions_html.py` PER-RUN DATA block. Update every run:

```
TODAY, GEN_TIME, SNAPSHOT, PORT_NAV, TOTAL_HEAT, HEAT_CLS
REGIME_LABEL, REGIME_SUB   ← from snapshot §4 regime label

For each dict in OPEN_POSITIONS:
  live_f          ← today's close price (float)
  unrealized_pct  ← (live_f - entry_f) / entry_f * 100
  flag_cls        ← "ok" | "warn" | "bad"
  scores          ← list of (leg, value, rationale) — CURRENT state from Step 5
  thesis          ← re-written for current position state (4–8 sentences):
                    what it is + where it stands now / mechanism per leg /
                    primary risk with price level / exact next action
  invalidation    ← list of (variable, kill_level, current_reading, status_cls)
                    look up current reading for each kill variable
                    "warn" if within 20% of kill; "bad" if breached
  key_vars        ← live V027 z-score, overlay gate status, flagged vars
  next_catalyst   ← most relevant upcoming event specifically for THIS position
  recommendation  ← HOLD / TRAIL STOP $X.XX (with breakeven price) / EXIT / TIGHTEN STOP
  development     ← dict with two keys (update every run when new events occur):
    entries       ← list of (date, type, event, detail) — chronological trade log
                    type: "fill" | "trim" | "stop" | "milestone" | "note"
                    Append new entries; do NOT overwrite prior ones.
                    Examples: tranche fills, stop moves, trims, Rule 2 trigger,
                    milestone closes (>1σ), thesis-validation events.
    thesis_evolution ← paragraph (one paragraph, 6–10 sentences, max 150 words):
                    how has the trade played out vs. expectation at entry? What's developed,
                    what's stalled, what's changed? Update to reflect today's state.
                    
                    REQUIRED STRUCTURE (in order):
                    1. ENTRY EXPECTATION (1 sentence): what the trade was betting on at entry — 
                       the specific mechanism that justified the edge. Reference Sum score and 
                       weakest leg (e.g., C=0).
                    2. WHAT HAPPENED (2–3 sentences): sequence of events since entry in chrono
                       order. Specific price levels, dates, % moves, fills/trims/stop moves. Include
                       one adverse development even if position runs well (trim, thin buffer, missed
                       milestone).
                    3. SCORE-BY-SCORE STATUS (2 sentences): for each leg that moved, state what
                       changed and why. Format: "S-leg: [still intact / strengthened / weakened] 
                       because [specific data]. T-leg: ... C-leg: ... R-leg: ..."
                       Skip legs with no change; note "unchanged."
                    4. SURPRISE DELTA (1 sentence): one thing that played out differently from
                       entry expectation — better or worse. If nothing surprised, name the biggest
                       unresolved uncertainty.
                    5. CURRENT STATUS (1 sentence): exactly one of: "Thesis running ahead of 
                       schedule." / "Thesis on track, not yet developing." / "Thesis stalling — 
                       reassess if [specific condition]." / "Thesis at risk — [specific variable] 
                       is the decision point."
                    6. NEXT MILESTONE (1 sentence): the single most important price level or event
                       that would confirm the next leg or trigger reassessment. Include exact number.
                    
                    RULES:
                    • No generic phrases ("thesis intact", "performing well"). Every sentence must 
                      contain a specific price, date, variable name, or %-move.
                    • If stop moved (Rule 2 or chandelier), state new stop level and actioned status.
                    • If below entry, explain why structural case still holds despite adverse action
                      — or flag that it no longer does.
                    • Do not summarize the thesis — analyse how it has developed since entry.

For each dict in PENDING_POSITIONS:
  status_cls, status_txt, scores, thesis, invalidation, recommendation

For FLAGS list: update status_cls and status_txt for all 13 flags.

Background and entry_context are mostly static — only update if a material
fundamental change occurred (CEO change, earnings result, stop hit on tranche).
development.entries: append-only — never delete prior events.
```

6b. Run: `python3 scripts/gen_positions_html.py`

6c. Verify: `{YYYY-MM-DD}/positions-monitor-{YYYY-MM-DD}.html` exists.

**Step 7 — Write MD flag file (CRITICAL/HIGH only)**
IF any CRITICAL or HIGH flag fired: write `{YYYY-MM-DD}/positions-monitor-{YYYY-MM-DD}.md` with flag table + per-position detail. Cite digest POSITION-ALERT timestamps for F12/F13.
If all green: skip MD.

**Step 8 — Update pipeline status**
Merge into `pipeline/.pipeline-status.json`:
```json
{
  "positions_monitor": {
    "date": "YYYY-MM-DD",
    "status": "OK or FLAGS",
    "flags_fired": N,
    "html": "YYYY-MM-DD/positions-monitor-YYYY-MM-DD.html"
  }
}
```

**Step 9 — Escalate CRITICAL flags**
If F2 (stop hit) or F8 (thesis breach): write to auto-memory immediately with ticker, price, and required action.

## Scope
Read-only observer. Does NOT modify `framework/Memory.md`, place orders, produce trade recs, or mark signals.
