# Stage B — Group T (Tactical Timing) network

**Nodes (K = 12).** V009 TSMOM, V010 revision breadth, V014 BTC exchange netflows, V017 BTC ETF flows, V026 residual momentum, C006 whale-ML, C007 perp funding arb, C008 BTC-ETH pairs, C012 Antonacci GEM, C013 crypto perp carry, C014 crypto perp basis, C015 overnight-intraday L/S.

**Asset-class anchors.** Cross-Asset (V009, C012), Equities (V010, V026, C015), Crypto (V014, V017, C006, C007, C008, C013, C014). Heavy crypto weighting — 7 of 12 — means the Crypto intercept `alpha_Crypto` carries most of the asset-class dispersion.

**Edges (pairs tested head-to-head with both Sharpes reported).** 0. No study in Stage A extraction performs a head-to-head horse race between two T variables with both Sharpes tabulated at the same construct. All inference is common-scale + asset-class-intercept.

**Peer adjacency (|correlation| ≥ 0.5).**

| node | declared peers | cluster |
|---|---|---|
| V009 | V026, C012 | Trend family |
| V026 | V009 | Trend family (residualized) |
| C012 | V009 | Trend family (GEM composite) |
| V010 | — | Equities revision (solo) |
| V014 | V017, C006, C007, C013, C014 | Crypto flow/positioning |
| V017 | V014 | Crypto flow (ETF) |
| C006 | V014 | Crypto flow (whale) |
| C007 | V014, C013, C014 | Crypto positioning (funding) |
| C013 | V014, C007, C014 | Crypto positioning (perp carry) |
| C014 | V014, C007, C013 | Crypto positioning (perp basis) |
| C008 | — | Narrow stat-arb (solo) |
| C015 | — | Equity intraday (solo) |

**Study inputs to likelihood (18 total study rows).**

- V009 TSMOM: 4 studies (Poh-Roberts-Zohren 2025 net 0.645; Song-Jeon 2025 0-bp-TC 1.41 — ZERO_COST_HEADLINE flag; MOP 2012 registry-aligned 0.90; SG CTA Trend Index 0.61)
- V010 Revision breadth: 1 study (Sharpe-Gil 2024 FEDS best bin 2.40 — SELECTION_BIAS flag)
- V014 BTC netflows: 2 studies, **order-flow cluster only** (Anastasopoulos L-only 1.88; Anastasopoulos orthogonalized L/S 1.34). Lee-Wang negative-sign vol-sort cluster deliberately excluded per m3 guidance.
- V017 BTC ETF flows: 0 studies (all replications have n ≤ 18 months — structural low power, prior-only)
- V026 Residual momentum: 3 studies (Gerard-Jehl 2025 FAJ Period I 0.444; Period II 0.767; Blitz 2011 JEF registry-aligned 0.70)
- C006: 1 (Herremans-Low 1.98, n=10 — SHORT_SAMPLE flag, SE dominates)
- C007: 1 (He-Manela-Ross-vonWachter BTC high-cost 1.80)
- C008: 1 (prior extraction 2.45, narrow 5-min universe)
- C012: 1 (Antonacci book + practitioner rep 0.80)
- C013: 1 (prior extraction 6.45, pre-cost narrow venue — PRE_COST flag)
- C014: 1 (estimated 3.50, pre-cost — PRE_COST flag)
- C015: 2 (Haghani-Ragulin-Dewey gross 3.00; net ~2.35)

**Pooling cautions.** T-group carries the highest heterogeneity in the BNMA — τ_med ranges 0.19 (V026) to 0.75 (C015). Most elevated τ values are single-study artifacts (τ absorbing distance between the study and the skeptical prior when there is no actual between-study variation to estimate). The two T-group heterogeneity flags with substantive meaning are **V014** (deliberately excluded negative-sign cluster; construct heterogeneity by design) and **V009** (construct/cost heterogeneity between 0-bp-TC ML and net CTA-implementation).

**Heterogeneity prior.** `tau_k ~ HalfNormal(0.25)` — S/T scale. Elevated posterior τ values are expected here and flagged in report §3.
