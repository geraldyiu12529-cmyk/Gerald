# Stage A — Consolidated Summary

Compiled from M1 (R+S literature validation), M2 (T-group replications + Tier 3 admission), and m3 (Sharpe extraction pass). This is the reproducible upstream artifact feeding the BNMA in Stages B–D. Full per-study detail is in the three source memos; this file is the registry-level roll-up consumed by `data.py`.

---

## Studies per variable

Total: 32 variables in main BNMA pool × (1 prior-only to 4 studies) = 23 likelihood-study rows plus 9 prior-only variables.

| group | var_id | name | tier | grade | n_studies | study_ids |
|---|---|---|---|---|---|---|
| S | V003 | DXY | 1 | A | 0 | (prior-only) |
| S | V006 | UST 2s10s | 1 | A | 0 | (prior-only) |
| S | V007 | Real yield/breakevens | 1 | A | 0 | (prior-only; post-2022 R² collapse noted) |
| S | V008 | ACM term premium 10Y | 1 | A | 0 | (prior-only; widened prior per M1) |
| S | V011 | Brent M1-M3 carry | 1 | A | 3 | V011-S1, V011-S2, V011-S3 |
| S | V012 | BTC active addresses | 1 | A | 0 | (prior-only) |
| S | V013 | BTC hash rate | 1 | A | 0 | (prior-only) |
| S | V019 | MVRV/SOPR | 2 | B | 0 | (prior-only; M1 recommends B→C) |
| S | V028 | Basis-momentum | 1 | A | 2 | V028-S1, V028-S2 |
| S | C004 | M2-vs-BTC cointegration | 3 | Tier3 | 0 | (NUMERIC_MISSING; surrogate β=2.65) |
| T | V009 | TSMOM | 1 | A | 4 | V009-S1 to V009-S4 |
| T | V010 | Revision breadth | 1 | A | 1 | V010-S1 (SELECTION_BIAS flag) |
| T | V014 | BTC exchange netflows | 1 | A | 2 | V014-S1, V014-S2 (order-flow cluster only) |
| T | V017 | BTC ETF net flows | 2 | B | 0 | (prior-only; all replications n≤18m) |
| T | V026 | Residual momentum (FF5) | 1 | A | 3 | V026-S1, V026-S2, V026-S3 |
| T | C006 | Whale-alert ML | 3 | Tier3 | 1 | C006-S1 (SHORT_SAMPLE) |
| T | C007 | Perp funding arb | 3 | Tier3 | 1 | C007-S1 |
| T | C008 | BTC-ETH pairs | 3 | Tier3 | 1 | C008-S1 |
| T | C012 | Antonacci GEM | 3 | Tier3 | 1 | C012-S1 |
| T | C013 | Crypto perp carry | 3 | Tier3 | 1 | C013-S1 (PRE_COST) |
| T | C014 | Crypto perp basis | 3 | Tier3 | 1 | C014-S1 (PRE_COST) |
| T | C015 | Overnight-intraday | 3 | Tier3 | 2 | C015-S1, C015-S2 |
| R | V001 | VIX | 1 | A | 3 | V001-S1, V001-S2, V001-S3 (CONSTRUCT_HETEROGENEOUS) |
| R | V002 | MOVE | 2 | A-minus | 0 | (prior-only; no clean independent Sharpe) |
| R | V004 | HY OAS / EBP | 1 | A | 1 | V004-S1 (ML_MULTI_FACTOR) |
| R | V005 | NFCI | 1 | A | 0 | (prior-only; GRADE_A_BOTTOM3 flag in D) |
| R | V015 | BTC realized vol | 2 | A-minus | 0 | (prior-only) |
| R | V016 | BTC perp funding | 2 | B | 0 | (prior-only) |
| R | V018 | BTC 3m basis | 2 | B | 0 | (prior-only) |
| R | V027 | Intermediary capital | 1 | A | 1 | V027-S1 (re-anchored on AEM 2014) |
| Overlay | C009 | Faber TAA | 3 | Tier3 | 2 | C009-S1, C009-S2 |
| Overlay | C011 | VIX futures term structure | 3 | Tier3 | 0 | (NUMERIC_MISSING; t-stat surrogate) |

---

## Admitted Tier 3 candidates (10 of 15 cap)

| candidate_id | name | score_component_assigned | grade_inferred | n_studies | first-pass verdict (Stage D) |
|---|---|---|---|---|---|
| C004 | M2-vs-BTC cointegration | S | Tier3 (working paper) | 0 | NEEDS_MORE_EVIDENCE |
| C006 | Whale-alert ML | T | Tier3 (working paper) | 1 | LOW_POWER_CANDIDATE |
| C007 | Perp funding arb | T | Tier3 (working paper) | 1 | LOW_POWER_CANDIDATE (peer-dominated) |
| C008 | BTC-ETH pairs | T | Tier3 (working paper) | 1 | WATCH (strong posterior, peer fallback) |
| C009 | Faber TAA | Overlay | Tier3 (working paper) | 2 | **PROMOTE** — sole formal graduate |
| C011 | VIX futures term structure | Overlay | Tier3 (peer-reviewed) | 0 | NEEDS_MORE_EVIDENCE |
| C012 | Antonacci GEM | T | Tier3 (working paper) | 1 | LOW_POWER_CANDIDATE (dominated by V009) |
| C013 | Crypto perp carry | T | Tier3 (working paper) | 1 | WATCH (merge candidate with C014) |
| C014 | Crypto perp basis | T | Tier3 (working paper) | 1 | WATCH (merge candidate with C013) |
| C015 | Overnight-intraday | T | Tier3 (working paper) | 2 | WATCH (conditional promote at 2026-10-14) |

---

## Rejected Tier 3 candidates (M2 Section 4)

9 rejections from the 19 embedded candidates. Reasons: CITATION_MISSING (7), EVENT_STUDY_NOT_SHARPE (2), REDUNDANT_WITH_REGISTRY (1), AMBIGUOUS_SCORE_COMPONENT (1). Full list in `candidates_rejected.csv`.

---

## Registry validation outcomes (Stage A.1)

- **17 of 17 Grade A/B primary citations PASS** for R + S groups (M1).
- **9 of 11 PASS** for remaining T / Overlay / C rows (M2); 2 FAILs:
  - V014: authorship error — Aloosh-Ouzan-Shahzad 2023 does not exist. **Corrected to Aloosh & Li 2024 Mgmt Sci 70(12):8875–8921.**
  - V031: journal name error — published in Journal of Portfolio Management, not Financial Analysts Journal. **Corrected.**

---

## m3 registry-anchor corrections (applied before Stage B)

| var_id | correction | rationale |
|---|---|---|
| V014 | Aloosh & Li 2024 Mgmt Sci (replaces non-existent Aloosh-Ouzan-Shahzad 2023) | Authorship + mechanism correct |
| V015 | Liu-Tsyvinski-Wu 2022 JF dual-listed alongside Liu-Tsyvinski 2021 RFS | 2022 paper contains the cross-sectional Sharpe anchor |
| V017-R1 | Oefele (not "Soeder") 2025, Economics Letters | Author name correction |
| V027 | Re-anchor on AEM 2014 SR ≈ 1.0 (HKM 2017 is non-traded by construction) | HKM has no tradable factor SR |
| V028 | Headline Sharpe 0.9 (not 1.2–1.5) | Primary paper text states 0.9 |
| V028-P2 | Fan & Zhang 2024 JFM 44(7):1097 (not "Fan-Ma-Wen JFM") | Author + journal name correction |
| V028-P3 | Qian, Jiang, Liu 2024/2025 JFM (not "Jiang-Liu EFMA") | Lead authorship correction |
| V027-P3 | Fontaine-Garcia-Gungor 2025 JoF 80(1):57 (not BoC WP) | Publication venue correction |
| V031 | Journal of Portfolio Management (not FAJ) | Journal name correction |

---

## Extraction-pass summary (m3)

- **17 of 29 targeted rows numeric** after pass (up from ~4 pre-m3).
- **19 NUMERIC_MISSING** in M2; **12 residual** after m3 extraction (paywall-blocked or regression-only studies).
- **5 se_imputed = TRUE** rows applied Lo (2002) formula.
- **82 of 100 search budget used.** No cap breach.

---

## Search-budget accounting

- Stage A.2 R+S replications (M1): logged 41 new studies, 23 with se-imputation, 7 NUMERIC_MISSING.
- Stage A.2 T replications (M2): logged 20 new studies, 19 NUMERIC_MISSING → m3 pass reduced to 10 residual.
- Stage A.3 Tier 3 candidate verification + fresh-search (M2): 18 total searches across both subagents; fresh-search phase proper used 4 of 10 allotment.
- m3 extraction pass: 82 of 100 total tool calls.

All budget caps respected; no silent cap breaches.

---

## Ready-for-Stage-B verdict

From m3: **GO for V009, V026, V027 (re-anchored), V028 (re-anchored), Tier 3 (8 of 10 numeric).** HOLD on V010 (exclude from primary, use in sensitivity only). EXCLUDE-FROM-POOL for V017 (structural low-power confirmed). PARTIAL-GO for V014 (cluster-level pooling only — order-flow cluster used, vol-sort cluster excluded).

These dispositions were honored in the data layer (`data.py`) and are reflected in the Stage C model fits and Stage D rankings.
