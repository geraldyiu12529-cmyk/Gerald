"""
BNMA data layer — variable roster, extracted Sharpes, priors, peer adjacency.

Sources:
- Registry (v4 prompt) for Var_ID, grade, published Sharpe, decay.
- M1 (Stage A.2 R+S), M2 (Stage A.2 T + Tier 3 admission), m3 (Sharpe extraction pass).

Conventions:
- "tier" = 1 (Grade A registry), 2 (Grade B registry, or replication-augmented),
          3 (admitted Tier 3 candidate).
- Prior means are post-decay projected operational Sharpe where registry supplies
  it; otherwise grade-anchored defaults.
- Prior SD tiering (per v4 spec): tighter for Tier 1, loose-skeptical for Tier 3.
- Effect-scale tiering: R/Overlay operate on a compressed scale (~0.0–0.4 per
  registry semantics). For variables where the literature reports long-short
  strategy Sharpes (V001, V004) we keep the raw number as the likelihood input
  and widen the heterogeneity prior in the R group — flagged as
  CONSTRUCT_HETEROGENEOUS in the report.
- se_imputed entries used Lo (2002): se ≈ sqrt((1 + SR^2/2) / n_months).
"""

import numpy as np
import pandas as pd


# ---------------------------------------------------------------------------
# VARIABLE ROSTER (32 variables across 4 groups)
# ---------------------------------------------------------------------------

VARIABLES = [
    # ------- S group (Structural Directional) -------
    dict(var_id="V003", name="DXY (Dollar Index)",             group="S", tier=1, grade="A",
         asset_class="Cross-Asset", registry_sharpe=0.50, decay=0.40,
         prior_mean=0.30, prior_sd=0.35,
         notes="Verdelhan 2018 JF; BIS WP 1083. No tradable SR extracted post-2023; prior-only."),
    dict(var_id="V006", name="UST 2s10s slope",                group="S", tier=1, grade="A",
         asset_class="Rates",       registry_sharpe=0.50, decay=0.40,
         prior_mean=0.25, prior_sd=0.35,
         notes="ACM 2013. 2022–24 inversion was largest post-76 failure; widened prior."),
    dict(var_id="V007", name="Real yield / Breakevens",        group="S", tier=1, grade="A",
         asset_class="Rates",       registry_sharpe=0.50, decay=0.50,
         prior_mean=0.15, prior_sd=0.45,
         notes="R^2 vs gold collapsed 84%->3-7% post-2022. Widened SD per M1."),
    dict(var_id="V008", name="ACM Term Premium 10Y",           group="S", tier=1, grade="A",
         asset_class="Rates",       registry_sharpe=0.50, decay=0.40,
         prior_mean=0.20, prior_sd=0.40,
         notes="Post-2013 MOVE/ACM break; 150bp model dispersion. Widened 50%."),
    dict(var_id="V011", name="Brent M1-M3 carry",              group="S", tier=1, grade="A",
         asset_class="Commodities", registry_sharpe=0.74, decay=0.40,
         prior_mean=0.44, prior_sd=0.25,
         notes="GHR 2013; KMPV 2018 carry SR 0.74. Fan 2024 SR 1.12, Rad-Zaremba SR 0.85."),
    dict(var_id="V012", name="BTC active addresses",           group="S", tier=1, grade="A",
         asset_class="Crypto",      registry_sharpe=0.40, decay=0.40,
         prior_mean=0.24, prior_sd=0.45,
         notes="Liu-Tsyvinski 2021 RFS / Cong-He-Li 2021. Identification strong, tradable SR inferred."),
    dict(var_id="V013", name="BTC hash rate",                  group="S", tier=1, grade="A",
         asset_class="Crypto",      registry_sharpe=0.35, decay=0.40,
         prior_mean=0.21, prior_sd=0.45,
         notes="Cong-He-Li 2021. Mostly contrarian capitulation signal; no tradable SR extracted."),
    dict(var_id="V019", name="MVRV / SOPR",                    group="S", tier=2, grade="B",
         asset_class="Crypto",      registry_sharpe=0.30, decay=0.40,
         prior_mean=0.10, prior_sd=0.45,
         notes="Practitioner-only. M1 recommends downgrade B->C; treated as Tier-2/skeptical."),
    dict(var_id="V028", name="Basis-Momentum (commodity)",     group="S", tier=1, grade="A",
         asset_class="Commodities", registry_sharpe=0.90, decay=0.40,
         prior_mean=0.54, prior_sd=0.25,
         notes="Boons-Prado 2019 headline 0.9 (corrected in m3, not 1.2-1.5). Audit target."),
    dict(var_id="C004", name="M2-vs-BTC macro cointegration",  group="S", tier=3, grade="Tier3",
         asset_class="Crypto",      registry_sharpe=None, decay=0.40,
         prior_mean=0.00, prior_sd=0.50,
         notes="Sarkar 2025 SSRN 5395221. NUMERIC_MISSING; beta=2.65 surrogate only. Prior-only."),

    # ------- T group (Tactical Timing) -------
    dict(var_id="V009", name="Time-series momentum (TSMOM)",   group="T", tier=1, grade="A",
         asset_class="Cross-Asset", registry_sharpe=0.90, decay=0.40,
         prior_mean=0.54, prior_sd=0.25,
         notes="MOP 2012; HOP 2017 replication. SG CTA Trend 0.61 real; Poh 2025 0.645 net."),
    dict(var_id="V010", name="Revision breadth",               group="T", tier=1, grade="A",
         asset_class="Equities",    registry_sharpe=0.50, decay=0.50,
         prior_mean=0.25, prior_sd=0.40,
         notes="Gleason-Lee 2003. Only bin-selected SR available; recommend near-prior treatment."),
    dict(var_id="V014", name="BTC exchange netflows",          group="T", tier=1, grade="A",
         asset_class="Crypto",      registry_sharpe=0.45, decay=0.40,
         prior_mean=0.27, prior_sd=0.40,
         notes="Aloosh-Li 2024 Mgmt Sci primary (corrected). Order-flow Sharpe cluster + vol-sort NEGATIVE cluster - do NOT pool naively."),
    dict(var_id="V017", name="BTC ETF net flows",              group="T", tier=2, grade="B",
         asset_class="Crypto",      registry_sharpe=0.30, decay=0.40,
         prior_mean=0.15, prior_sd=0.40,
         notes="Short-sample (n<=18m). Exclude from Sharpe pool; prior only. Regression surrogate available."),
    dict(var_id="V026", name="Residual momentum (FF5)",        group="T", tier=1, grade="A",
         asset_class="Equities",    registry_sharpe=0.70, decay=0.40,
         prior_mean=0.42, prior_sd=0.25,
         notes="Blitz et al 2011; AMP 2013. Gerard-Jehl 2025 SR 0.444/0.767. Audit target."),
    dict(var_id="C006", name="Whale-alert ML momentum",        group="T", tier=3, grade="Tier3",
         asset_class="Crypto",      registry_sharpe=None, decay=0.40,
         prior_mean=0.00, prior_sd=0.50,
         notes="Herremans-Low 2022 arXiv. SR 1.98 but n~10 months, se ~1.85 - short-sample critical."),
    dict(var_id="C007", name="Perp funding-rate arb",          group="T", tier=3, grade="Tier3",
         asset_class="Crypto",      registry_sharpe=None, decay=0.40,
         prior_mean=0.00, prior_sd=0.50,
         notes="He-Manela-Ross-vonWachter 2024. BTC high-cost SR 1.80 (realistic)."),
    dict(var_id="C008", name="BTC-ETH statistical pairs",      group="T", tier=3, grade="Tier3",
         asset_class="Crypto",      registry_sharpe=None, decay=0.40,
         prior_mean=0.00, prior_sd=0.50,
         notes="Prior Tier 3 extraction: SR 2.45. Narrow-universe arb."),
    dict(var_id="C012", name="Antonacci GEM dual momentum",    group="T", tier=3, grade="Tier3",
         asset_class="Cross-Asset", registry_sharpe=None, decay=0.40,
         prior_mean=0.10, prior_sd=0.45,
         notes="Antonacci 2014 orig. Published SR ~0.7-0.9 in practitioner studies; se_imputed."),
    dict(var_id="C013", name="Crypto perp carry",              group="T", tier=3, grade="Tier3",
         asset_class="Crypto",      registry_sharpe=None, decay=0.40,
         prior_mean=0.00, prior_sd=0.50,
         notes="Prior extraction SR 6.45 (pre-cost, narrow venue). Very aggressive."),
    dict(var_id="C014", name="Crypto perp basis",              group="T", tier=3, grade="Tier3",
         asset_class="Crypto",      registry_sharpe=None, decay=0.40,
         prior_mean=0.00, prior_sd=0.50,
         notes="Related construct to C013; partial overlap."),
    dict(var_id="C015", name="Overnight-intraday L/S",         group="T", tier=3, grade="Tier3",
         asset_class="Equities",    registry_sharpe=None, decay=0.30,
         prior_mean=0.20, prior_sd=0.45,
         notes="Haghani-Ragulin-Dewey 2024 'Night Moves'. SR 3.0 gross / 2.2-2.5 net (30% decay)."),

    # ------- R group (Risk Overlay) -------
    dict(var_id="V001", name="VIX",                             group="R", tier=1, grade="A",
         asset_class="Cross-Asset", registry_sharpe=0.50, decay=0.40,
         prior_mean=0.30, prior_sd=0.35,
         notes="Whaley 2000. Tsai 2025 SR 1.7 (L/S futures) and vol-managed 100-150bps - CONSTRUCT_HETEROGENEOUS."),
    dict(var_id="V002", name="MOVE Index",                      group="R", tier=2, grade="A-minus",
         asset_class="Cross-Asset", registry_sharpe=0.40, decay=0.40,
         prior_mean=0.20, prior_sd=0.35,
         notes="Siriwardane 2019 JF. Borup 2024 MS embeds MOVE but no clean SR. A-minus per M1."),
    dict(var_id="V004", name="HY OAS / Excess Bond Premium",    group="R", tier=1, grade="A",
         asset_class="Credit",      registry_sharpe=0.50, decay=0.40,
         prior_mean=0.30, prior_sd=0.35,
         notes="Gilchrist-Zakrajsek 2012. Hu 2024 JFE ML SR 3.27 is multi-factor - widened prior."),
    dict(var_id="V005", name="NFCI",                            group="R", tier=1, grade="A",
         asset_class="Cross-Asset", registry_sharpe=0.35, decay=0.40,
         prior_mean=0.21, prior_sd=0.35,
         notes="Brave-Butters 2012. No clean tradable SR; English-Liang: predictability concentrated 2008."),
    dict(var_id="V015", name="BTC realized vol",                group="R", tier=2, grade="A-minus",
         asset_class="Crypto",      registry_sharpe=0.40, decay=0.40,
         prior_mean=0.15, prior_sd=0.35,
         notes="Liu-Tsyvinski-Wu 2022 JF is correct anchor. M1 recommends A-minus."),
    dict(var_id="V016", name="BTC perp funding rate",           group="R", tier=2, grade="B",
         asset_class="Crypto",      registry_sharpe=0.30, decay=0.40,
         prior_mean=0.15, prior_sd=0.30,
         notes="As risk overlay (different use than C007 arb). Prior-only."),
    dict(var_id="V018", name="BTC 3m basis",                    group="R", tier=2, grade="B",
         asset_class="Crypto",      registry_sharpe=0.25, decay=0.40,
         prior_mean=0.15, prior_sd=0.30,
         notes="Practitioner-dominant. Prior-only."),
    dict(var_id="V027", name="Intermediary capital ratio",      group="R", tier=1, grade="A",
         asset_class="Cross-Asset", registry_sharpe=1.00, decay=0.40,
         prior_mean=0.60, prior_sd=0.25,
         notes="RE-ANCHORED in m3: AEM 2014 LMP SR ~=1.0 (not HKM 2017 which is non-traded). Audit target."),

    # ------- Overlay (Regime filter) -------
    dict(var_id="C009", name="Faber TAA (10-month SMA + GTAA)", group="Overlay", tier=3, grade="Tier3",
         asset_class="Cross-Asset", registry_sharpe=None, decay=0.30,
         prior_mean=0.20, prior_sd=0.30,
         notes="Faber 2013 rev. SMA SR 0.55 vs BH 0.32; GTAA 5-asset 0.73 vs 0.44 - delta ~0.2-0.3."),
    dict(var_id="C011", name="VIX futures term structure",      group="Overlay", tier=3, grade="Tier3",
         asset_class="Cross-Asset", registry_sharpe=None, decay=0.40,
         prior_mean=0.10, prior_sd=0.30,
         notes="Fassas-Hourvouliades 2019 JRFM. NUMERIC_MISSING (regression only); t=-3.7 surrogate."),
]

DF_VARS = pd.DataFrame(VARIABLES)


# ---------------------------------------------------------------------------
# EXTRACTED STUDY-LEVEL DATA (per M3 Sharpe extraction pass + prior knowledge)
# Each row: var_id, study_id, sharpe, sharpe_se, n_months, se_imputed, flags.
# Variables with no row here get prior-only treatment.
# ---------------------------------------------------------------------------

STUDIES = [
    # ---- V011 Brent carry ----
    dict(var_id="V011", study_id="V011-S1", sharpe=1.12, sharpe_se=0.14, n_months=480,
         se_imputed=True, flag="", citation="Fan 2024 JFM fixed-stop commodity carry, post-TC"),
    dict(var_id="V011", study_id="V011-S2", sharpe=0.85, sharpe_se=0.14, n_months=360,
         se_imputed=True, flag="", citation="Rad-Zaremba 2019 JFIN curve-momentum net"),
    dict(var_id="V011", study_id="V011-S3", sharpe=0.74, sharpe_se=0.09, n_months=600,
         se_imputed=True, flag="", citation="KMPV 2018 carry, cross-asset avg"),

    # ---- V028 Basis-momentum ----
    dict(var_id="V028", study_id="V028-S1", sharpe=0.90, sharpe_se=0.16, n_months=660,
         se_imputed=True, flag="", citation="Boons-Prado 2019 JF (corrected headline 0.9)"),
    dict(var_id="V028", study_id="V028-S2", sharpe=0.92, sharpe_se=0.19, n_months=486,
         se_imputed=True, flag="", citation="Fan-Zhang 2024 JFM fixed-stop avg net"),
    # V028-S3: Qian-Jiang-Liu reports SR IMPROVEMENT of 0.13, not a standalone SR - not added as
    # a likelihood input to avoid scale confusion; used as qualitative corroboration.

    # ---- V009 TSMOM ----
    dict(var_id="V009", study_id="V009-S1", sharpe=0.645, sharpe_se=0.073, n_months=234,
         se_imputed=True, flag="", citation="Poh-Roberts-Zohren 2025 arXiv NMM-DTW-E net"),
    dict(var_id="V009", study_id="V009-S2", sharpe=1.411, sharpe_se=0.079, n_months=318,
         se_imputed=True, flag="ZERO_COST_HEADLINE",
         citation="Song-Jeon 2025 PLoS ONE MTDP 4wk (0-bp TC only - fragile)"),
    dict(var_id="V009", study_id="V009-S3", sharpe=0.90, sharpe_se=0.12, n_months=228,
         se_imputed=True, flag="", citation="MOP 2012 JFE primary, registry-aligned"),
    dict(var_id="V009", study_id="V009-S4", sharpe=0.61, sharpe_se=0.10, n_months=288,
         se_imputed=True, flag="", citation="SG CTA Trend Index 2000-2024 implementation-adjusted"),

    # ---- V010 Revision breadth (bin-selected; flag) ----
    dict(var_id="V010", study_id="V010-S1", sharpe=2.40, sharpe_se=0.253, n_months=60,
         se_imputed=True, flag="SELECTION_BIAS",
         citation="Sharpe-Gil 2024 FEDS best 'High-High' bin of 6 - selection-biased"),

    # ---- V014 BTC netflows (TWO CLUSTERS - do not pool naively) ----
    # We include only the order-flow cluster here (positive side); the negative vol-sort
    # cluster (Lee-Wang) is a different construct and flagged separately in the report.
    dict(var_id="V014", study_id="V014-S1", sharpe=1.88, sharpe_se=0.23, n_months=54,
         se_imputed=True, flag="LONG_ONLY_VARIANT",
         citation="Anastasopoulos-Gradojevic et al order-flow, long-only"),
    dict(var_id="V014", study_id="V014-S2", sharpe=1.34, sharpe_se=0.19, n_months=54,
         se_imputed=True, flag="ORTHOGONALIZED",
         citation="Anastasopoulos-Gradojevic et al daily orthogonalized L/S"),

    # ---- V026 Residual momentum ----
    dict(var_id="V026", study_id="V026-S1", sharpe=0.444, sharpe_se=0.058, n_months=387,
         se_imputed=True, flag="", citation="Gerard-Jehl 2025 FAJ Period I"),
    dict(var_id="V026", study_id="V026-S2", sharpe=0.767, sharpe_se=0.081, n_months=177,
         se_imputed=True, flag="RECENT_SUBSAMPLE",
         citation="Gerard-Jehl 2025 FAJ Period II (2010-24)"),
    dict(var_id="V026", study_id="V026-S3", sharpe=0.70, sharpe_se=0.12, n_months=240,
         se_imputed=True, flag="", citation="Blitz et al 2011 JEF registry-aligned"),

    # ---- C006 Whale-alert ----
    dict(var_id="C006", study_id="C006-S1", sharpe=1.98, sharpe_se=1.85, n_months=10,
         se_imputed=True, flag="SHORT_SAMPLE",
         citation="Herremans-Low 2022 (wide SE swamps point est)"),

    # ---- C007 Funding arb ----
    dict(var_id="C007", study_id="C007-S1", sharpe=1.80, sharpe_se=1.10, n_months=50,
         se_imputed=True, flag="",
         citation="He-Manela-Ross-vonWachter 2024 BTC high-cost (realistic)"),

    # ---- C008 BTC-ETH pairs ----
    dict(var_id="C008", study_id="C008-S1", sharpe=2.45, sharpe_se=0.50, n_months=48,
         se_imputed=True, flag="NARROW_UNIVERSE",
         citation="Prior Tier-3 extraction, narrow-universe stat arb"),

    # ---- C012 Antonacci GEM ----
    dict(var_id="C012", study_id="C012-S1", sharpe=0.80, sharpe_se=0.20, n_months=480,
         se_imputed=True, flag="PRACTITIONER",
         citation="Antonacci 2014 book + practitioner replications"),

    # ---- C013 Perp carry ----
    dict(var_id="C013", study_id="C013-S1", sharpe=6.45, sharpe_se=1.20, n_months=36,
         se_imputed=True, flag="PRE_COST_NARROW_VENUE",
         citation="Prior Tier-3 extraction (pre-cost, narrow venue) - aggressive"),

    # ---- C014 Perp basis ----
    dict(var_id="C014", study_id="C014-S1", sharpe=3.50, sharpe_se=0.90, n_months=36,
         se_imputed=True, flag="PRE_COST",
         citation="Related construct to C013; estimated from partial literature"),

    # ---- C015 Overnight L/S ----
    dict(var_id="C015", study_id="C015-S1", sharpe=3.00, sharpe_se=0.124, n_months=360,
         se_imputed=True, flag="GROSS",
         citation="Haghani-Ragulin-Dewey 2024 'Night Moves' gross"),
    dict(var_id="C015", study_id="C015-S2", sharpe=2.35, sharpe_se=0.13, n_months=360,
         se_imputed=True, flag="NET_EST",
         citation="Same source - net ~2.2-2.5 after ~5%/yr TC + 1%/yr borrow"),

    # ---- V001 VIX ----
    dict(var_id="V001", study_id="V001-S1", sharpe=1.70, sharpe_se=0.21, n_months=228,
         se_imputed=True, flag="LONG_SHORT_FUTURES",
         citation="Tsai 2025 QF adaptive boosting VIX L/S (distinct construct from overlay)"),
    dict(var_id="V001", study_id="V001-S2", sharpe=0.623, sharpe_se=0.35, n_months=60,
         se_imputed=True, flag="C_MVO",
         citation="PMC 2024 VIX C-MVO walk-forward ML IR"),
    dict(var_id="V001", study_id="V001-S3", sharpe=0.45, sharpe_se=0.12, n_months=360,
         se_imputed=True, flag="VOL_MANAGED",
         citation="Dai-Wu 2024 / Clarke-de Silva-Thorley 2020 rep, vol-managed alpha 100-150bps"),

    # ---- V004 HY OAS ----
    dict(var_id="V004", study_id="V004-S1", sharpe=3.27, sharpe_se=0.19, n_months=216,
         se_imputed=True, flag="ML_MULTI_FACTOR",
         citation="Hu et al 2024 JFE RF bond L/S - EBP is one predictor of many"),

    # ---- V027 Intermediary capital (RE-ANCHORED) ----
    dict(var_id="V027", study_id="V027-S1", sharpe=1.00, sharpe_se=0.19, n_months=504,
         se_imputed=True, flag="",
         citation="Adrian-Etula-Muir 2014 JF LMP annualized (re-anchor)"),

    # ---- C009 Faber TAA (Overlay) ----
    dict(var_id="C009", study_id="C009-S1", sharpe=0.23, sharpe_se=0.04, n_months=1344,
         se_imputed=True, flag="DELTA_SMA",
         citation="Faber SMA improvement (0.55 - 0.32 buy-hold)"),
    dict(var_id="C009", study_id="C009-S2", sharpe=0.29, sharpe_se=0.07, n_months=480,
         se_imputed=True, flag="DELTA_GTAA",
         citation="Faber GTAA 5-asset improvement (0.73 - 0.44)"),
]

DF_STUDIES = pd.DataFrame(STUDIES)


# ---------------------------------------------------------------------------
# PEER ADJACENCY (for marginal-contribution computation; |correlation| >= 0.5)
# Keys: var_id -> list of peer var_ids in the SAME group.
# ---------------------------------------------------------------------------

PEERS = {
    # S group
    "V003": [],
    "V006": ["V007", "V008"],
    "V007": ["V006", "V008"],
    "V008": ["V006", "V007"],
    "V011": ["V028"],              # static slope + dynamic complement; explicit dual-use
    "V028": ["V011"],
    "V012": ["V013", "V019"],      # BTC on-chain fundamentals
    "V013": ["V012", "V019"],
    "V019": ["V012", "V013"],
    "C004": [],                    # macro-cointegration, unique
    # T group
    "V009": ["V026", "C012"],      # trend family
    "V026": ["V009"],              # residualized trend
    "C012": ["V009"],              # dual momentum uses TSMOM-like legs
    "V010": [],
    "V014": ["C007", "C013", "C014", "V017"],   # crypto flow/positioning
    "V017": ["V014"],
    "C006": ["V014"],              # whale-flow momentum
    "C007": ["C013", "C014", "V014", "V016"],
    "C008": [],                    # stat-arb, unique-ish
    "C013": ["C014", "C007", "V014"],
    "C014": ["C013", "C007", "V014"],
    "C015": [],
    # R group
    "V001": ["V002", "V005"],      # cross-asset vol/stress
    "V002": ["V001", "V005"],
    "V004": ["V005", "V027"],      # credit/dealer-capacity
    "V005": ["V001", "V002", "V004"],
    "V015": [],                    # BTC vol, own market
    "V016": ["V018"],
    "V018": ["V016"],
    "V027": ["V004"],              # dealer constraints + credit stress
    # Overlay
    "C009": [],                    # TAA SMA
    "C011": [],                    # VIX term structure
}


def get_group_data(group):
    """Return (vars_df, studies_df) for a group."""
    v = DF_VARS[DF_VARS["group"] == group].reset_index(drop=True)
    s = DF_STUDIES[DF_STUDIES["var_id"].isin(v["var_id"])].reset_index(drop=True)
    return v, s


if __name__ == "__main__":
    for g in ["S", "T", "R", "Overlay"]:
        v, s = get_group_data(g)
        print(f"Group {g}: {len(v)} variables, {len(s)} studies")
        print(v[["var_id", "name", "tier", "grade", "prior_mean", "prior_sd"]].to_string(index=False))
        print()
