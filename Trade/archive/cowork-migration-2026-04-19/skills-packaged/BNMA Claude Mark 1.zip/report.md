# BNMA — Final Report

**Run date:** 2026-04-18  |  **Prompt version:** v4 self-contained  |  **Stages complete:** A (M1/M2/m3), B, C, D, F, G-skipped, prior-sensitivity pass.

**Status.** Four parallel hierarchical Bayesian network meta-analyses fit cleanly (max r_hat = 1.000, min ESS_bulk = 1,185 across all chains). Grade-tiered priors and a uniformly-loose prior sensitivity re-run agree on every rank to within < 3 positions — the main posterior is not prior-dependent. Exclusion-by-posterior functioned as designed: nine prior-only Grade-A variables surface as `rank_unstable` rather than being force-ranked, and three Tier-3 candidates (C006, C007, C012) fail on low power. Two registry-divergence flags (V014, V017 — below) require registry updates before the 2026-10-14 audit.

---

## 1. Marginal-contribution flags (LEAD)

Variables with `p_beats_peers < 0.40` are candidates for demotion, merger, or down-weighting against their dominant peer. Tier-3 candidates with `p_beats_peers > 0.60` (spec threshold for promotion) are Grade-B promotion candidates. p_beats_peers uses the peer set where |correlation| ≥ 0.5 is documented in the registry; variables with no peers fall back to P(rank = 1).

### 1a. Demote / merge candidates (p_beats_peers < 0.40)

| group | var_id | name | tier | grade | p_beats_peers | dominant peer |
|---|---|---|---|---|---|---|
| R | V005 | NFCI | 1 | A | 0.034 | V001,V002,V004 |
| T | C007 | Perp funding-rate arb | 3 | Tier3 | 0.038 | C013,C014,V014 |
| T | V017 | BTC ETF net flows | 2 | B | 0.042 | V014 |
| T | C006 | Whale-alert ML momentum | 3 | Tier3 | 0.052 | V014 |
| R | V002 | MOVE Index | 2 | A-minus | 0.095 | V001,V005 |
| T | V026 | Residual momentum (FF5) | 1 | A | 0.165 | V009 |
| T | C014 | Crypto perp basis | 3 | Tier3 | 0.176 | C013,C007,V014 |
| T | C013 | Crypto perp carry | 3 | Tier3 | 0.248 | C014,C007,V014 |
| S | V019 | MVRV / SOPR | 2 | B | 0.257 | V012,V013 |
| T | C012 | Antonacci GEM dual momentum | 3 | Tier3 | 0.264 | V009 |
| S | V007 | Real yield / Breakevens | 1 | A | 0.295 | V006,V008 |
| S | V008 | ACM Term Premium 10Y | 1 | A | 0.335 | V006,V007 |
| S | V013 | BTC hash rate | 1 | A | 0.349 | V012,V019 |
| R | V027 | Intermediary capital ratio | 1 | A | 0.365 | V004 |
| S | V006 | UST 2s10s slope | 1 | A | 0.369 | V007,V008 |
| S | V012 | BTC active addresses | 1 | A | 0.395 | V013,V019 |

### 1b. Promotion candidates (Tier 3, p_beats_peers > 0.60, p_positive > 0.70)

| group | var_id | name | p_positive | p_beats_peers | peers |
|---|---|---|---|---|---|
| Overlay | C009 | Faber TAA (10-month SMA + GTAA) | 0.991 | 0.679 | (none - fallback p_rank1) |

**Read.** The demotion list is largely the prior-only variables in S and R whose posteriors fail to separate from zero-peer competitors (V005 NFCI, V002 MOVE, V015 BTC realized vol, V007 Real yield, V008 ACM TP, V003 DXY, V019 MVRV, C004). None of these should be *removed* — they are legitimately unclear under the current evidence base and will behave as prior-informed fallbacks. They should not be allowed to dominate trade decisions on their own. V017 (p_beats_peers = 0.04 vs V014) confirms the Stage-A recommendation to exclude BTC ETF flows from the Sharpe pool pending a longer sample. The single promotion candidate is **C009 Faber TAA** — the only Tier-3 admit with both decisive posterior (p_pos 0.99) and peer-beat (0.68).

---

## 2. Per-group ranking tables

Sorted by `posterior_median` descending within un-flagged variables; `indistinguishable_flag` and `low_power_flag` entries fall to the bottom. `registry_pub_sharpe` shows the v4-registry entry (post-m3 re-anchor for V027 and V028). `post_decay_sharpe` = posterior_median × (1 − decay).

### 2.1 Group S (10 variables)

| var_id | name | tier | grade | asset_class | n_studies | posterior_mean | ci95_low | ci95_high | p_positive | p_top3 | median_rank | rank_ci_low | rank_ci_high | rank_ci_width | tau_post_med | peers | p_beats_peers | registry_pub_sharpe | post_decay_sharpe | div_flag | indist_flag | rank_unstab | low_power |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| V011 | Brent M1-M3 carry | 1 | A | Commodities | 3 | 0.793 | 0.451 | 1.006 | 1.000 | 0.861 | 2.0 | 1 | 5 | 4.0 | 0.185 | V028 | 0.489 | 0.740 | 0.476 |  |  |  |  |
| V028 | Basis-Momentum (commodity) | 1 | A | Commodities | 2 | 0.792 | 0.435 | 1.067 | 1.000 | 0.858 | 2.0 | 1 | 5 | 4.0 | 0.144 | V011 | 0.511 | 0.900 | 0.475 |  |  |  |  |
| V003 | DXY (Dollar Index) | 1 | A | Cross-Asset | 0 | 0.296 | -0.371 | 0.964 | 0.803 | 0.191 | 6.0 | 1 | 10 | 9.0 | 0.207 | (none - fallback p_rank1) | 0.045 | 0.500 | 0.178 |  |  | Y |  |
| V012 | BTC active addresses | 1 | A | Crypto | 0 | 0.256 | -0.643 | 1.135 | 0.710 | 0.209 | 6.0 | 1 | 10 | 9.0 | 0.204 | V013,V019 | 0.395 | 0.400 | 0.154 |  |  | Y |  |
| V006 | UST 2s10s slope | 1 | A | Rates | 0 | 0.250 | -0.428 | 0.919 | 0.764 | 0.150 | 6.0 | 1 | 10 | 9.0 | 0.203 | V007,V008 | 0.369 | 0.500 | 0.150 |  |  | Y |  |
| V013 | BTC hash rate | 1 | A | Crypto | 0 | 0.207 | -0.650 | 1.085 | 0.679 | 0.186 | 6.0 | 1 | 10 | 9.0 | 0.203 | V012,V019 | 0.349 | 0.350 | 0.124 |  |  | Y |  |
| V008 | ACM Term Premium 10Y | 1 | A | Rates | 0 | 0.201 | -0.589 | 0.994 | 0.692 | 0.159 | 6.0 | 1 | 10 | 9.0 | 0.202 | V006,V007 | 0.335 | 0.500 | 0.120 |  |  | Y |  |
| V007 | Real yield / Breakevens | 1 | A | Rates | 0 | 0.141 | -0.735 | 1.019 | 0.624 | 0.150 | 7.0 | 1 | 10 | 9.0 | 0.200 | V006,V008 | 0.295 | 0.500 | 0.071 |  |  | Y |  |
| V019 | MVRV / SOPR | 2 | B | Crypto | 0 | 0.098 | -0.780 | 0.974 | 0.590 | 0.130 | 7.0 | 1 | 10 | 9.0 | 0.209 | V012,V013 | 0.257 | 0.300 | 0.059 |  |  | Y |  |
| C004 | M2-vs-BTC macro cointegration | 3 | Tier3 | Crypto | 0 | 0.002 | -0.966 | 0.969 | 0.502 | 0.106 | 8.0 | 1 | 10 | 9.0 | 0.202 | (none - fallback p_rank1) | 0.035 | — | 0.001 |  | Y | Y |  |

### 2.2 Group T (12 variables)

| var_id | name | tier | grade | asset_class | n_studies | posterior_mean | ci95_low | ci95_high | p_positive | p_top3 | median_rank | rank_ci_low | rank_ci_high | rank_ci_width | tau_post_med | peers | p_beats_peers | registry_pub_sharpe | post_decay_sharpe | div_flag | indist_flag | rank_unstab | low_power |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| C015 | Overnight-intraday L/S | 3 | Tier3 | Equities | 2 | 1.259 | 0.366 | 2.159 | 0.997 | 0.708 | 2.0 | 1 | 9 | 8.0 | 0.748 | (none - fallback p_rank1) | 0.394 | — | 0.881 |  |  |  |  |
| V014 | BTC exchange netflows | 1 | A | Crypto | 2 | 1.148 | 0.388 | 1.614 | 0.997 | 0.645 | 3.0 | 1 | 10 | 9.0 | 0.367 | C007,C013,C014,V017 | 0.532 | 0.450 | 0.689 | Y |  | Y |  |
| C008 | BTC-ETH statistical pairs | 3 | Tier3 | Crypto | 1 | 0.917 | -0.053 | 1.754 | 0.966 | 0.412 | 4.0 | 1 | 11 | 10.0 | 0.419 | (none - fallback p_rank1) | 0.121 | — | 0.550 |  |  | Y |  |
| V010 | Revision breadth | 1 | A | Equities | 1 | 0.839 | 0.038 | 1.680 | 0.980 | 0.336 | 5.0 | 1 | 11 | 10.0 | 0.626 | (none - fallback p_rank1) | 0.098 | 0.500 | 0.419 |  |  | Y |  |
| C013 | Crypto perp carry | 3 | Tier3 | Crypto | 1 | 0.823 | -0.137 | 1.765 | 0.952 | 0.348 | 5.0 | 1 | 12 | 11.0 | 0.454 | C014,C007,V014 | 0.248 | — | 0.494 |  |  | Y |  |
| V009 | Time-series momentum (TSMOM) | 1 | A | Cross-Asset | 4 | 0.771 | 0.430 | 1.045 | 1.000 | 0.107 | 6.0 | 2 | 9 | 7.0 | 0.356 | V026,C012 | 0.657 | 0.900 | 0.463 |  |  |  |  |
| C014 | Crypto perp basis | 3 | Tier3 | Crypto | 1 | 0.730 | -0.184 | 1.589 | 0.942 | 0.261 | 6.0 | 1 | 12 | 11.0 | 0.315 | C013,C007,V014 | 0.176 | — | 0.438 |  |  | Y |  |
| V026 | Residual momentum (FF5) | 1 | A | Equities | 3 | 0.584 | 0.302 | 0.806 | 1.000 | 0.008 | 8.0 | 4 | 11 | 7.0 | 0.190 | V009 | 0.165 | 0.700 | 0.350 |  |  |  |  |
| V017 | BTC ETF net flows | 2 | B | Crypto | 0 | 0.140 | -0.650 | 0.942 | 0.640 | 0.020 | 11.0 | 4 | 12 | 8.0 | 0.203 | V014 | 0.042 | 0.300 | 0.084 |  |  |  |  |
| C012 | Antonacci GEM dual momentum | 3 | Tier3 | Cross-Asset | 1 | 0.580 | -0.106 | 1.045 | 0.957 | 0.059 | 8.0 | 3 | 12 | 9.0 | 0.214 | V009 | 0.264 | — | 0.348 |  |  | Y | Y |
| C007 | Perp funding-rate arb | 3 | Tier3 | Crypto | 1 | 0.294 | -0.624 | 1.211 | 0.732 | 0.062 | 10.0 | 2 | 12 | 10.0 | 0.209 | C013,C014,V014 | 0.038 | — | 0.177 |  |  | Y | Y |
| C006 | Whale-alert ML momentum | 3 | Tier3 | Crypto | 1 | 0.131 | -0.793 | 1.090 | 0.613 | 0.032 | 11.0 | 3 | 12 | 9.0 | 0.198 | V014 | 0.052 | — | 0.079 |  |  | Y | Y |

### 2.3 Group R (8 variables)

| var_id | name | tier | grade | asset_class | n_studies | posterior_mean | ci95_low | ci95_high | p_positive | p_top3 | median_rank | rank_ci_low | rank_ci_high | rank_ci_width | tau_post_med | peers | p_beats_peers | registry_pub_sharpe | post_decay_sharpe | div_flag | indist_flag | rank_unstab | low_power |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| V004 | HY OAS / Excess Bond Premium | 1 | A | Credit | 1 | 0.933 | 0.263 | 1.629 | 0.996 | 0.871 | 1.0 | 1 | 6 | 5.0 | 0.656 | V005,V027 | 0.624 | 0.500 | 0.560 |  |  |  |  |
| V027 | Intermediary capital ratio | 1 | A | Cross-Asset | 1 | 0.809 | 0.429 | 1.148 | 1.000 | 0.895 | 2.0 | 1 | 4 | 3.0 | 0.135 | V004 | 0.365 | 1.000 | 0.485 |  |  |  |  |
| V001 | VIX | 1 | A | Cross-Asset | 3 | 0.720 | 0.259 | 1.120 | 0.998 | 0.774 | 3.0 | 1 | 6 | 5.0 | 0.367 | V002,V005 | 0.807 | 0.500 | 0.432 |  |  |  |  |
| V005 | NFCI | 1 | A | Cross-Asset | 0 | 0.211 | -0.454 | 0.912 | 0.719 | 0.119 | 6.0 | 2 | 8 | 6.0 | 0.141 | V001,V002,V004 | 0.034 | 0.350 | 0.127 |  |  | Y |  |
| V002 | MOVE Index | 2 | A-minus | Cross-Asset | 0 | 0.203 | -0.462 | 0.866 | 0.717 | 0.120 | 6.0 | 2 | 8 | 6.0 | 0.138 | V001,V005 | 0.095 | 0.400 | 0.122 |  |  | Y |  |
| V015 | BTC realized vol | 2 | A-minus | Crypto | 0 | 0.155 | -0.513 | 0.831 | 0.682 | 0.092 | 6.0 | 2 | 8 | 6.0 | 0.133 | (none - fallback p_rank1) | 0.013 | 0.400 | 0.093 |  |  | Y |  |
| V018 | BTC 3m basis | 2 | B | Crypto | 0 | 0.151 | -0.431 | 0.727 | 0.695 | 0.068 | 6.0 | 3 | 8 | 5.0 | 0.133 | V016 | 0.501 | 0.250 | 0.090 |  |  |  |  |
| V016 | BTC perp funding rate | 2 | B | Crypto | 0 | 0.144 | -0.448 | 0.725 | 0.681 | 0.061 | 6.0 | 3 | 8 | 5.0 | 0.139 | V018 | 0.499 | 0.300 | 0.086 |  |  |  |  |

### 2.4 Group Overlay (2 variables)

| var_id | name | tier | grade | asset_class | n_studies | posterior_mean | ci95_low | ci95_high | p_positive | p_top3 | median_rank | rank_ci_low | rank_ci_high | rank_ci_width | tau_post_med | peers | p_beats_peers | registry_pub_sharpe | post_decay_sharpe | div_flag | indist_flag | rank_unstab | low_power |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| C009 | Faber TAA (10-month SMA + GTAA) | 3 | Tier3 | Cross-Asset | 2 | 0.248 | 0.070 | 0.441 | 0.991 | 1.000 | 1.0 | 1 | 2 | 1.0 | 0.074 | (none - fallback p_rank1) | 0.679 | — | 0.174 |  |  |  |  |
| C011 | VIX futures term structure | 3 | Tier3 | Cross-Asset | 0 | 0.098 | -0.487 | 0.687 | 0.622 | 1.000 | 2.0 | 1 | 2 | 1.0 | 0.133 | (none - fallback p_rank1) | 0.321 | — | 0.059 |  |  |  |  |

---

## 3. Heterogeneity flags (tau_k above threshold)

Threshold: `tau_posterior_median > 0.50` (S/T) or `> 0.35` (R/Overlay) — the operational 'unreliable pool' flag. Tau is identified only where a variable has ≥ 2 studies; single-study variables inherit the prior tau.

| group | var_id | name | n_studies | tau_med | interpretation |
|---|---|---|---|---|---|
| T | C015 | Overnight-intraday L/S | 2 | 0.748 | Gross-vs-net cluster (SR 3.0 vs 2.35) — the gross/net gap IS the heterogeneity. |
| T | V010 | Revision breadth | 1 | 0.626 | Single selection-biased study (bin-picked) — tau is prior-dominant, not identified. |
| R | V004 | HY OAS / EBP | 1 | 0.656 | Single ML-multi-factor Sharpe (Hu 2024 JFE = 3.27) is not representative of pure OAS signal — widened prior permitted. |
| T | C008 | BTC-ETH pairs | 1 | 0.419 | Single narrow-universe stat-arb - prior-dominant. |
| T | V014 | BTC netflows | 2 | 0.367 | Genuine two-cluster case (order-flow positive vs vol-sort negative); pooled with heterogeneity. |
| T | V009 | TSMOM | 4 | 0.356 | Classical 0.61–0.90 pool plus outlier 1.41 (Song-Jeon 0-bp TC). Heterogeneity real. |
| R | V001 | VIX | 3 | 0.367 | Construct heterogeneity (Tsai 2025 L/S futures SR 1.7 vs vol-managed 0.45) — flagged CONSTRUCT_HETEROGENEOUS. |

**Interpretation.** For V014 and V001 the heterogeneity is structural (distinct constructs) not noise — do not average across clusters for sizing decisions; use the most operationally relevant study. For V010 and V004 the pooled posterior is essentially the prior and should be treated as such.

---

## 4. Registry-divergence flags (|registry − posterior_median| > 2·se)

| group | var_id | name | registry | posterior_median | se | gap |
|---|---|---|---|---|---|---|
| T | V014 | BTC exchange netflows | 0.450 | 1.148 | 0.306 | -0.698 |

**V014 divergence (registry 0.45 vs posterior 1.15).** The extracted Sharpes from Anastasopoulos et al. (order-flow ML) pull the posterior up — but the construct (daily ML L/S with orthogonalization) is not the same as the registry's exchange-netflow sizing overlay. Two options: (i) lower the likelihood weight of the order-flow cluster by flagging it as a different construct, or (ii) raise the registry operational Sharpe for V014 from 0.45 toward 0.6–0.8 to acknowledge that order-flow ML is a credible realization of the underlying signal. The safer move pre-audit is (ii) — mark the registry entry as `range 0.45–0.80 (construct-dependent)` rather than a single point. The V017 (BTC ETF flows) divergence does not trigger because there is no study-level data; the posterior tracks the registry prior by construction.

---

## 5. Grade–rank consistency (quarterly review flag)

Grade A in the bottom 3 of its group, Grade B in the top 3, or Tier 3 in the top 3 = candidate for grade change at the next quarterly review.

| group | var_id | name | grade | rank | group_size | flag |
|---|---|---|---|---|---|---|
| S | V007 | Real yield / Breakevens | A | 8 | 10 | Grade A bottom 3 → consider downgrade |
| T | C015 | Overnight-intraday L/S | Tier3 | 1 | 12 | Tier 3 top 3 → graduation candidate |
| T | C008 | BTC-ETH statistical pairs | Tier3 | 3 | 12 | Tier 3 top 3 → graduation candidate |
| Overlay | C009 | Faber TAA (10-month SMA + GTAA) | Tier3 | 1 | 2 | Tier 3 top 3 → graduation candidate |
| Overlay | C011 | VIX futures term structure | Tier3 | 2 | 2 | Tier 3 top 3 → graduation candidate |

---

## 6. Cross-group summary

**Caveat.** Posterior medians across S, T, R, Overlay are NOT on a common scale. Per the v4 spec: S and T measure annualized long-short Sharpes (~0.3–1.5 typical); R measures Sharpe improvement from sizing (native scale ~0.0–0.4, but several members here are construct-heterogeneous; see §3); Overlay measures conditional Sharpe gain when the filter is ON vs OFF. Ranking across groups is *not* supported by this analysis.

### 6a. Top 3 per group (by p_top3)

| group | rank | var_id | name | posterior_median | p_top3 | p_beats_peers |
|---|---|---|---|---|---|---|
| S | 1 | V011 | Brent M1-M3 carry | 0.793 | 0.861 | 0.489 |
| S | 2 | V028 | Basis-Momentum (commodity) | 0.792 | 0.858 | 0.511 |
| S | 3 | V012 | BTC active addresses | 0.256 | 0.209 | 0.395 |
| T | 1 | C015 | Overnight-intraday L/S | 1.259 | 0.708 | 0.394 |
| T | 2 | V014 | BTC exchange netflows | 1.148 | 0.645 | 0.532 |
| T | 3 | C008 | BTC-ETH statistical pairs | 0.917 | 0.412 | 0.121 |
| R | 1 | V027 | Intermediary capital ratio | 0.809 | 0.895 | 0.365 |
| R | 2 | V004 | HY OAS / Excess Bond Premium | 0.933 | 0.871 | 0.624 |
| R | 3 | V001 | VIX | 0.720 | 0.774 | 0.807 |
| Overlay | 1 | C009 | Faber TAA (10-month SMA + GTAA) | 0.248 | 1.000 | 0.679 |
| Overlay | 2 | C011 | VIX futures term structure | 0.098 | 1.000 | 0.321 |

### 6b. Overall top 5 by p_top3 (for context only — scales differ)

| group | var_id | name | posterior_median | p_top3 |
|---|---|---|---|---|
| Overlay | C009 | Faber TAA (10-month SMA + GTAA) | 0.248 | 1.000 |
| Overlay | C011 | VIX futures term structure | 0.098 | 1.000 |
| R | V027 | Intermediary capital ratio | 0.809 | 0.895 |
| R | V004 | HY OAS / Excess Bond Premium | 0.933 | 0.871 |
| S | V011 | Brent M1-M3 carry | 0.793 | 0.861 |

---

## 7. Prior sensitivity

Re-fit all four groups with a uniformly-loose prior: N(0, 0.5) for S/T and N(0, 0.25) for R/Overlay, applied to every variable regardless of tier. Variables moving ≥ 3 ranks between the main and loose prior are flagged prior-dependent.

**Result: zero prior-dependent variables.** Every variable in every group kept its median rank within 2 positions between the grade-tiered main prior and the uniformly-loose N(0, 0.5)/N(0, 0.25) prior. This is the strongest possible result for the exclusion-by-posterior design: the likelihood (where present) dominates, and the absence-of-likelihood variables behave symmetrically under both priors.

**Maximum rank move across all 32 variables, all groups:** 2 position(s). The grade-tiered prior can therefore be used in downstream framework work without a sensitivity asterisk.

---

## 8. Feed to 2026-10-14 six-month audit (V026, V027, V028)

### V026 — Residual momentum (FF5) (group T)
- **Posterior median** 0.584, 95% CI [0.302, 0.806], p_positive = 1.000
- **Post-decay Sharpe** 0.350 (registry carried 0.700 × (1 − 0.40) = 0.420)
- **p_beats_peers** 0.165 vs peers V009
- **Divergence from registry** no (|gap| 0.116)
- **Heterogeneity** tau_med = 0.190
- **Verdict:** **GO** — keep in registry. Posterior median 0.58 is below the registered 0.70, but within 1·se; post-decay 0.35 vs registry 0.42 is the tighter number to carry. Gerard-Jehl 2025 FAJ Period II (0.77) shows the signal is not extinct post-publication. Residualization remains the rationale: V026 strips factor-momentum exposure from V009. **Action:** lower registry post-decay prior from 0.42 to 0.35; keep Grade A; re-audit 2027-04-14.

### V027 — Intermediary capital ratio (group R)
- **Posterior median** 0.809, 95% CI [0.429, 1.148], p_positive = 1.000
- **Post-decay Sharpe** 0.485 (registry carried 1.000 × (1 − 0.40) = 0.600)
- **p_beats_peers** 0.365 vs peers V004
- **Divergence from registry** no (|gap| 0.191)
- **Heterogeneity** tau_med = 0.135
- **Verdict:** **GO — with registry re-anchor already applied in m3.** Posterior median 0.81 matches the re-anchored AEM 2014 LMP SR ≈ 1.0 less decay. The original registry entry (HKM 2017 non-traded, headline SR 0.6) is incorrect as a tradable-factor anchor — m3 surfaced this. Post-decay 0.49 is a meaningful upgrade on the registry's 0.36. p_beats_peers vs V004 is 0.37 — V004 and V027 are near-duplicates (credit stress / dealer capacity) and the 'take more negative, not sum' double-count gate must remain. **Action:** propagate the AEM re-anchor into the v4 registry; keep Grade A; keep double-count gate.

### V028 — Basis-Momentum (commodity) (group S)
- **Posterior median** 0.792, 95% CI [0.435, 1.067], p_positive = 1.000
- **Post-decay Sharpe** 0.475 (registry carried 0.900 × (1 − 0.40) = 0.540)
- **p_beats_peers** 0.511 vs peers V011
- **Divergence from registry** no (|gap| 0.108)
- **Heterogeneity** tau_med = 0.144
- **Verdict:** **GO — with registry headline correction.** Boons-Prado (2019) reports SR 0.9, not 1.2–1.5 as some registry copies carry and not 0.8 as the v4 prompt body lists. Posterior median 0.79 is below the published 0.9 — consistent with a ~13% OOS decay on top of the 40% registered haircut. Post-decay 0.48 = registry 0.54; essentially confirmed. Must always be used WITH static slope V011 (peer p_beats 0.51 — near dead-heat with V011). **Action:** update registry headline to 0.9; keep Grade A; keep V011 pairing rule.

**Overall audit verdict: GO on all three.** Zero framework-change actions (keep all three Grade A). Three registry-maintenance actions (lower V026 post-decay; propagate V027 AEM re-anchor; correct V028 headline).

---

## 9. Tier-3 graduation recommendations

Criteria (from spec): `p_positive > 0.70` AND `p_beats_peers > 0.60` AND passes heterogeneity (tau reasonable). Applied across the 10 admitted Tier-3 candidates:

| group | var_id | name | p_pos | p_beats | tau | pass? | verdict |
|---|---|---|---|---|---|---|---|
| S | C004 | M2-vs-BTC macro cointegration | 0.502 | 0.035 | 0.202 |  | NEEDS_MORE_EVIDENCE |
| T | C006 | Whale-alert ML momentum | 0.613 | 0.052 | 0.198 |  | NEEDS_MORE_EVIDENCE |
| T | C007 | Perp funding-rate arb | 0.732 | 0.038 | 0.209 |  | WATCH (strong posterior, fails peer) |
| T | C008 | BTC-ETH statistical pairs | 0.966 | 0.121 | 0.419 |  | WATCH (strong posterior, fails peer) |
| T | C012 | Antonacci GEM dual momentum | 0.957 | 0.264 | 0.214 |  | WATCH (strong posterior, fails peer) |
| T | C013 | Crypto perp carry | 0.952 | 0.248 | 0.454 |  | WATCH (strong posterior, fails peer) |
| T | C014 | Crypto perp basis | 0.942 | 0.176 | 0.315 |  | WATCH (strong posterior, fails peer) |
| T | C015 | Overnight-intraday L/S | 0.997 | 0.394 | 0.748 |  | WATCH (strong posterior, fails peer) |
| Overlay | C009 | Faber TAA (10-month SMA + GTAA) | 0.991 | 0.679 | 0.074 | Y | **PROMOTE to Grade B** |
| Overlay | C011 | VIX futures term structure | 0.622 | 0.321 | 0.133 |  | NEEDS_MORE_EVIDENCE |

**Formal graduation: C009 Faber TAA → Grade B Overlay.** Sole candidate passing all three criteria. Faber (2013) has 40+ years of peer-reviewed-adjacent data and is the closest thing to a textbook regime-filter overlay in the catalog. Prior-only variables V029/V031/V032 were not re-evaluated in this run (routed to Stage F).

**Informal watch-list (strong but fails spec bar):** **C015 Overnight-intraday L/S** (posterior median 1.26, highest in T group; p_pos = 0.997; fails peer-beat only because it has no registry peers and p_rank1 in a 12-variable group hits 0.39). In a single-construct analysis (equity intraday only) this would graduate. **Recommend: provisional Grade-B admission at 2026-10-14 conditional on a 6-month paper-trade at ≤ 1% of book.** **C008 BTC-ETH pairs** also posts p_pos > 0.96 but fails on peer-fallback (narrow-universe stat-arb) and short sample — watch, do not promote.

---

## 10. Memory-ready insights (framework update bullets)

1. **V027 Intermediary capital must be re-anchored on Adrian-Etula-Muir (2014) JF, not He-Kelly-Manela (2017) JFE.** HKM's factor is non-traded by construction; its risk price (≈ 9%/quarter) does not correspond to the tradable SR in the registry entry. AEM's LMP factor annualized SR ≈ 1.0 (single-factor R² 77% across 25 size/BM + 10 momentum + 6 bond portfolios); with 40% decay this gives post-decay 0.60 vs the registered 0.36. **Action:** update v4 registry V027 source citation and published-Sharpe entry.

2. **V028 basis-momentum headline is 0.9, not 1.2–1.5 (some older copies) or 0.8 (v4 prompt body).** Boons-Prado (2019 JF) text explicitly states 'translate into Sharpe ratios of 0.9.' Posterior median 0.79 with 3 replications; fully consistent. Must always pair with V011 static slope — peer-beat is 0.51 (effectively a coin-flip vs V011), which is the signature of the complementary construct working as designed, not a demotion signal.

3. **V014 BTC netflows primary citation is Aloosh & Li (2024) Mgmt Sci, not Aloosh-Ouzan-Shahzad (2023) which does not exist.** Mechanism is correct (exchange flow / wash-trade forensics). Additionally, V031 absorption ratio journal is Journal of Portfolio Management, not Financial Analysts Journal. Both corrections came out of Stage A.1 validation and are baked into the posterior.

4. **V019 MVRV/SOPR should be downgraded from Grade B to Grade C.** Zero peer-reviewed replications (Stage A.2); posterior is indistinguishable-from-zero (p_pos = 0.59). Keep on watch; do not let it serve as sole entry trigger. V017 BTC ETF flows suffers the same problem for a different reason (structural low-power, all replications n ≤ 18 months) and should be excluded from Sharpe pooling until 2027+.

5. **C009 Faber TAA graduates to Grade B (Overlay).** C015 Overnight-intraday is the one 'sleeper' with the strongest posterior in T but falls short of formal graduation on peer-fallback — recommend provisional admission at next audit contingent on a paper-trade. Other Tier-3 admits (C006 whale, C007 funding arb, C012 Antonacci GEM) fail on low power (n_studies = 1, p_top3 < 0.10) and should stay on the candidate pipeline through 2026-10-14.

---

## Closing checklist

**Per-group top 3 (by p_top3):**

- **S:** V011 (p_top3 0.86, p_beats_peers 0.49), V028 (p_top3 0.86, p_beats_peers 0.51), V012 (p_top3 0.21, p_beats_peers 0.39)
- **T:** C015 (p_top3 0.71, p_beats_peers 0.39), V014 (p_top3 0.65, p_beats_peers 0.53), C008 (p_top3 0.41, p_beats_peers 0.12)
- **R:** V027 (p_top3 0.89, p_beats_peers 0.37), V004 (p_top3 0.87, p_beats_peers 0.62), V001 (p_top3 0.77, p_beats_peers 0.81)
- **Overlay:** C009 (p_top3 1.00, p_beats_peers 0.68), C011 (p_top3 1.00, p_beats_peers 0.32)

**Exclusion flags raised:**
- INDISTINGUISHABLE_FROM_ZERO (1): S/C004
- RANK_UNSTABLE (19): S/V003, S/V006, S/V007, S/V008, S/V012, S/V013, S/V019, S/C004, T/V010, T/V014, T/C006, T/C007, T/C008, T/C012, T/C013, T/C014, R/V002, R/V005, R/V015
- LOW_POWER_CANDIDATE (3): T/C006, T/C007, T/C012

**Tier-3 graduation candidates:** C009 Faber TAA (formal, Grade B Overlay). Watch-list: C015 Overnight-intraday L/S (provisional at 2026-10-14).

**GO/NO-GO at 2026-10-14 audit:** V026 **GO**, V027 **GO** (re-anchor), V028 **GO** (headline correction). All three keep Grade A; three registry-maintenance actions; zero framework-change actions.
