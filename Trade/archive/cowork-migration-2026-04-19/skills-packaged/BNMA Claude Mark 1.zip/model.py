"""
BNMA hierarchical model, run per group.

Model (per group g, K variables, N_k studies each):
    mu_k     ~ Normal(prior_mean_k, prior_sd_k)        # variable-level true effect
    tau_k    ~ HalfNormal(tau_scale_g)                 # between-study heterogeneity
    theta_ik ~ Normal(mu_k, tau_k)                     # study-level true effect
    y_ik     ~ Normal(theta_ik, sigma_ik)              # observed Sharpe, sigma known

tau_scale: 0.30 for S/T (broader heterogeneity allowed); 0.20 for R/Overlay
(compressed effect scale per registry).

Prior sensitivity: uniformly-loose re-run with N(0, 0.5) S/T, N(0, 0.25) R/Overlay
for all tiers.

Outputs:
    - trace_{group}.nc     arviz InferenceData
    - ranking_{group}.csv  ranking table per spec
"""

import os
import numpy as np
import pandas as pd
import pymc as pm
import arviz as az
import warnings

from data import DF_VARS, DF_STUDIES, PEERS, get_group_data

warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)

TAU_SCALE = {"S": 0.30, "T": 0.30, "R": 0.20, "Overlay": 0.20}
N_DRAWS = 2000
N_TUNE = 1500
N_CHAINS = 3
RNG_SEED = 20260418


def build_and_fit(group, loose_prior=False):
    """Fit BNMA for one group. Returns (trace, vars_df)."""
    vdf, sdf = get_group_data(group)
    K = len(vdf)
    varid_to_k = {vid: i for i, vid in enumerate(vdf["var_id"])}
    tau_scale = TAU_SCALE[group]

    prior_mean = vdf["prior_mean"].to_numpy()
    prior_sd = vdf["prior_sd"].to_numpy()

    if loose_prior:
        # Uniformly-loose prior sensitivity pass
        prior_mean = np.zeros(K)
        prior_sd = np.full(K, 0.5 if group in ("S", "T") else 0.25)

    # Study-level arrays
    if len(sdf) > 0:
        k_idx = sdf["var_id"].map(varid_to_k).to_numpy()
        y_obs = sdf["sharpe"].to_numpy()
        sigma = sdf["sharpe_se"].to_numpy()
    else:
        k_idx = np.array([], dtype=int)
        y_obs = np.array([])
        sigma = np.array([])

    with pm.Model() as model:
        mu = pm.Normal("mu", mu=prior_mean, sigma=prior_sd, shape=K)
        tau = pm.HalfNormal("tau", sigma=tau_scale, shape=K)

        if len(y_obs) > 0:
            # Non-centered parameterization
            theta_raw = pm.Normal("theta_raw", mu=0, sigma=1, shape=len(y_obs))
            theta = pm.Deterministic("theta", mu[k_idx] + tau[k_idx] * theta_raw)
            pm.Normal("y", mu=theta, sigma=sigma, observed=y_obs)

        trace = pm.sample(
            draws=N_DRAWS, tune=N_TUNE, chains=N_CHAINS, cores=1,
            target_accept=0.95, random_seed=RNG_SEED,
            progressbar=False, return_inferencedata=True,
        )

    return trace, vdf


def compute_rank_stats(trace, vdf, group):
    """Compute posterior summaries + rank distributions + peer comparisons."""
    mu_draws = trace.posterior["mu"].values  # shape (chain, draw, K)
    mu_flat = mu_draws.reshape(-1, mu_draws.shape[-1])  # (S, K)
    tau_flat = trace.posterior["tau"].values.reshape(-1, mu_draws.shape[-1])
    K = mu_flat.shape[1]
    S = mu_flat.shape[0]

    # Posterior summaries
    mean = mu_flat.mean(axis=0)
    median = np.median(mu_flat, axis=0)
    ci_low = np.percentile(mu_flat, 2.5, axis=0)
    ci_high = np.percentile(mu_flat, 97.5, axis=0)
    p_positive = (mu_flat > 0).mean(axis=0)

    # Rank distribution: in each draw, rank variables by mu (highest = rank 1)
    # argsort descending -> position gives rank
    ranks = np.empty_like(mu_flat, dtype=int)
    for s in range(S):
        order = np.argsort(-mu_flat[s])          # indices sorted high->low
        r = np.empty(K, dtype=int)
        r[order] = np.arange(1, K + 1)
        ranks[s] = r

    median_rank = np.median(ranks, axis=0)
    rank_low = np.percentile(ranks, 2.5, axis=0)
    rank_high = np.percentile(ranks, 97.5, axis=0)
    rank_ci_width = rank_high - rank_low
    p_top3 = (ranks <= 3).mean(axis=0)
    p_rank1 = (ranks == 1).mean(axis=0)

    # tau posterior
    tau_med = np.median(tau_flat, axis=0)

    # Peer-based marginal contribution
    var_ids = vdf["var_id"].tolist()
    p_beats_peers = []
    peer_names = []
    for i, vid in enumerate(var_ids):
        peers = [p for p in PEERS.get(vid, []) if p in var_ids]
        if len(peers) == 0:
            # Fallback to P(rank=1)
            p_beats_peers.append(p_rank1[i])
            peer_names.append("(none - fallback p_rank1)")
        else:
            peer_idx = [var_ids.index(p) for p in peers]
            peer_max = mu_flat[:, peer_idx].max(axis=1)
            p_beats = (mu_flat[:, i] > peer_max).mean()
            p_beats_peers.append(p_beats)
            peer_names.append(",".join(peers))

    # Assemble
    out = vdf.copy()
    out["posterior_mean"] = mean
    out["posterior_median"] = median
    out["ci95_low"] = ci_low
    out["ci95_high"] = ci_high
    out["p_positive"] = p_positive
    out["median_rank"] = median_rank
    out["rank_ci_low"] = rank_low
    out["rank_ci_high"] = rank_high
    out["rank_ci_width"] = rank_ci_width
    out["p_top3"] = p_top3
    out["p_rank1"] = p_rank1
    out["tau_posterior_median"] = tau_med
    out["peers"] = peer_names
    out["p_beats_peers"] = p_beats_peers

    # Post-decay Sharpe
    out["post_decay_sharpe"] = out["posterior_median"] * (1 - out["decay"])

    # Divergence flag: |registry - posterior_median| > 2*se (use ci_high - ci_low /4 as se proxy)
    se_proxy = (out["ci95_high"] - out["ci95_low"]) / 4.0
    out["divergence_flag"] = (
        out["registry_sharpe"].fillna(out["posterior_median"]) - out["posterior_median"]
    ).abs() > 2 * se_proxy

    # Exclusion flags
    out["indistinguishable_flag"] = out["p_positive"] < 0.55
    out["rank_unstable_flag"] = out["rank_ci_width"] > 0.7 * K
    n_studies_per_var = DF_STUDIES.groupby("var_id").size()
    out["n_studies"] = out["var_id"].map(n_studies_per_var).fillna(0).astype(int)
    out["low_power_flag"] = (
        (out["tier"] == 3) & (out["n_studies"] <= 1) & (out["p_top3"] < 0.10)
    )

    out["group"] = group
    return out


def fit_all_groups(loose_prior=False, outdir="/home/claude/bnma"):
    tag = "_loose" if loose_prior else ""
    results = {}
    for g in ["S", "T", "R", "Overlay"]:
        print(f"\n=== Fitting group {g} {'(LOOSE PRIOR)' if loose_prior else ''} ===")
        trace, vdf = build_and_fit(g, loose_prior=loose_prior)
        rank_df = compute_rank_stats(trace, vdf, g)
        results[g] = rank_df

        # Save
        trace_path = os.path.join(outdir, "traces", f"trace_{g}{tag}.nc")
        az.to_netcdf(trace, trace_path)
        csv_path = os.path.join(outdir, f"ranking_{g}{tag}.csv")
        rank_df.to_csv(csv_path, index=False)

        # Convergence diagnostic
        summary = az.summary(trace, var_names=["mu", "tau"])
        max_rhat = summary["r_hat"].max()
        min_ess = summary["ess_bulk"].min()
        print(f"  max r_hat={max_rhat:.3f}  min ess_bulk={min_ess:.0f}")
        if max_rhat > 1.05:
            print(f"  WARNING: r_hat > 1.05 in group {g}")

    return results


if __name__ == "__main__":
    print("=" * 60)
    print("MAIN FIT (grade-tiered priors)")
    print("=" * 60)
    main_results = fit_all_groups(loose_prior=False)

    print()
    print("=" * 60)
    print("PRIOR SENSITIVITY (uniformly-loose)")
    print("=" * 60)
    loose_results = fit_all_groups(loose_prior=True)

    # Cross-group summary
    all_main = pd.concat(main_results.values(), ignore_index=True)
    all_loose = pd.concat(loose_results.values(), ignore_index=True)

    all_main.to_csv("/home/claude/bnma/ranking_all.csv", index=False)
    all_loose.to_csv("/home/claude/bnma/ranking_all_loose.csv", index=False)

    # Rank-move sensitivity: compare median_rank main vs loose per group
    merged = all_main[["group", "var_id", "median_rank"]].merge(
        all_loose[["group", "var_id", "median_rank"]],
        on=["group", "var_id"], suffixes=("_main", "_loose"),
    )
    merged["rank_move"] = (merged["median_rank_main"] - merged["median_rank_loose"]).abs()
    merged["prior_dependent"] = merged["rank_move"] >= 3
    merged.to_csv("/home/claude/bnma/prior_sensitivity.csv", index=False)

    print("\nPrior-dependent variables (|rank move| >= 3):")
    print(merged[merged["prior_dependent"]].to_string(index=False))
    print("\nAll fits complete.")
