# Stage B — Group Overlay (Regime Filter) network

**Nodes (K = 2).** C009 Faber TAA (10-month SMA + GTAA), C011 VIX futures term structure.

**Why K = 2 only.** The v4 registry Overlay entries (V029 GEX, V031 absorption ratio, V032 ML feature importance) are all Provisional or Ungraded and route to Stage F, not main ranking. V031 had a clean journal-name correction (Journal of Portfolio Management, not FAJ) applied in Stage A.1 but remains Provisional. The main-ranking Overlay group therefore consists entirely of Tier-3 admitted candidates.

**Asset-class anchors.** Both Cross-Asset.

**Edges (head-to-head).** 0. No study tests the two candidates against each other.

**Peer adjacency.** Neither variable has a declared peer in the Overlay group; `p_beats_peers` falls back to P(rank = 1) for both.

**Study inputs to likelihood (2 total study rows).**

- C009 Faber TAA: 2 studies, both from Faber (2013 rev) SSRN 962461. C009-S1 = SPX 10-month SMA improvement delta of 0.23 (timing 0.55 − buy-hold 0.32) on 1901–2012, se 0.029; C009-S2 = GTAA 5-asset improvement delta of 0.29 (timing 0.73 − buy-hold 0.44) on 1973–2012, se 0.051. Both entered on the overlay **delta** scale (improvement over buy-hold), not raw strategy Sharpe — this matches the Overlay spec of "conditional Sharpe gain when filter ON vs OFF."
- C011 VIX futures term structure: 0 studies (Fassas-Hourvouliades 2019 reports regression t-stats only, not Sharpe — NUMERIC_MISSING). Prior-only treatment.

**Effect scale note.** Overlay group effect size is "conditional Sharpe gain when filter is ON vs OFF" per v4 spec. Both C009 study entries are correctly on this scale (delta, not raw). Posterior median for C009 = 0.25 means a ~0.25 Sharpe improvement when the SMA filter is ON vs raw buy-hold — this matches the roughly 0.2–0.3 delta range of the source data.

**Posterior verdict and Stage F routing.** C009 posterior CI [0.07, 0.44] is tight and entirely above zero; p_positive = 0.991; p_beats_peers = 0.679 (fallback to p_rank1 because no peer — but this is the highest p_rank1 in the group). Promotion to Grade B Overlay at next quarterly recommended. C011 posterior CI [−0.49, 0.69] straddles zero, p_positive = 0.62; HOLD for more numeric evidence. V029, V031, V032 and watch-list rejects (200-DMA breadth, etc.) routed to Stage F for watch-only tracking.

**Heterogeneity prior.** `tau_k ~ HalfNormal(0.15)` — R/Overlay scale. C009 τ_med = 0.074 (well below threshold; consistent two-study pool); C011 τ_med = 0.133 (prior-dominant, no studies).
