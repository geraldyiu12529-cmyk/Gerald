# Stage F — Candidate Pipeline

Merged holdings: (a) Provisional/Ungraded registry rows not included in main ranking, (b) Tier 3 candidates flagged LOW_POWER_CANDIDATE in Stage D, (c) admitted Tier 3 candidates that failed `p_beats_peers` against registry peers but may carry independent information, (d) Stage A.3 rejected candidates on watch-list.

---

## (a) Provisional / Ungraded registry rows

| var_id | name | registered citation | score_component | grade | verdict | rationale |
|---|---|---|---|---|---|---|
| V020 | News sentiment | Tetlock 2007 JF / Garcia 2013 JoF | C | B | OUT_OF_BNMA_SCOPE | C-group (catalyst); event-study scale, not long-short Sharpe. Tracked in news-events pipeline, not BNMA. |
| V029 | GEX (Gamma Exposure) | Barbon-Buraschi 2021 SSRN 3725454 | Overlay | Provisional | WATCH | Mechanism well-understood (dealer hedging polarity). No extracted Sharpe numeric; would need dealer-gamma tape access to backtest. Re-evaluate at 2026-10-14 if a peer-reviewed tradable-SR paper emerges. |
| V030 | Cross-asset lead-lag | Lo-MacKinlay 1990 RFS | T | Provisional | WATCH | Overlaps with TSMOM for the led asset. Would need explicit lead-lag pair roster (BTC→ETH, NVDA→semis, Copper→ISM, MOVE→VIX) with tradable-strategy Sharpes per pair. No such numerics extracted in Stage A.2. |
| V031 | Correlation regime (absorption ratio) | Kritzman et al 2011 JPM (corrected) | Overlay | Provisional | WATCH | Journal correction applied (JPM not FAJ). Mechanism works as meta-filter (signal quality degrades when cross-asset correlation is high). No tradable-SR extracted. Re-evaluate at 2026-10-14. |
| V032 | Decision tree feature importance | Gu-Kelly-Xiu 2020 RFS | Overlay | Ungraded | NEEDS_MORE_EVIDENCE | Meta-variable; not a standalone signal. Role is to surface interaction effects. Would need a separately-testable forecast to enter BNMA. |
| V033 | Pre-FOMC drift / calendar | Lucca-Moench 2015 JoF | C | Ungraded | OUT_OF_BNMA_SCOPE | C-group (catalyst). Keep as overlay in calendar-based sizing; not scored in BNMA. |

---

## (b) Tier 3 admitted candidates flagged LOW_POWER_CANDIDATE in Stage D

Criterion: Tier 3 AND n_studies ≤ 1 AND p_top3 < 0.10.

| var_id | name | citation | score_component | p_pos | p_top3 | verdict | notes |
|---|---|---|---|---|---|---|---|
| C006 | Whale-alert ML momentum | Herremans-Low 2022 arXiv 2211.08281 | T | 0.613 | 0.032 | NEEDS_MORE_EVIDENCE | n_months = 10, SE = 1.85 swamps point estimate (SR 1.98). Single study, 10-month OOS window. Watch for longer-sample replication. |
| C007 | Perp funding-rate arb | He-Manela-Ross-vonWachter 2024 arXiv 2212.06888 | T | 0.732 | 0.062 | WATCH | Strong posterior but fully dominated by perp-positioning peer cluster (p_beats_peers = 0.038). Mechanism distinct from C013/C014 (delta-neutral vs directional carry); keep on watch for a paper isolating funding-only construct. |
| C012 | Antonacci GEM dual momentum | Antonacci 2014 SSRN 2042750 / JME 2017 | T | 0.957 | 0.060 | WATCH | Dominated by V009 TSMOM (peer beat 0.264). Treat as practitioner composite of registered constructs rather than independent Grade-B candidate. Operational value: as a portfolio-rotation rule, not a signal. |

---

## (c) Admitted Tier 3 that failed peer-dominance but carry independent info

| var_id | name | score_component | p_pos | p_beats_peers | verdict | notes |
|---|---|---|---|---|---|---|
| C008 | BTC-ETH statistical pairs | T | 0.966 | 0.121 (fallback p_rank1) | WATCH | Strong posterior (0.92). Failure on peer-dominance is the fallback-to-p_rank1 issue (no declared peer in T). Narrow-universe 5-min stat-arb; depends on execution. PROMOTE conditional on 5-min execution availability. |
| C013 | Crypto perp carry | T | 0.952 | 0.248 vs C014/C007/V014 | WATCH | Aggressive pre-cost 6.45; largely dominated by perp cluster. Recommend MERGE with V014 flow-suite rather than independent admission. |
| C014 | Crypto perp basis | T | 0.942 | 0.176 vs C013/C007/V014 | WATCH | Conceptual/numeric overlap with C013. MERGE with C013 (keep one) and fold into V014 flow-suite operational note. |
| C015 | Overnight-intraday L/S | T | 0.997 | 0.394 (fallback p_rank1) | PROMOTE_AT_NEXT_QUARTERLY (conditional) | Highest T-group posterior (1.26) but falls short on peer-fallback because it has no declared peer. Recommend provisional Grade B admission at 2026-10-14 conditional on a 6-month paper-trade at ≤ 1% of book. Link to V033 (pre-FOMC drift) as a declared peer if retained. |
| C011 | VIX futures term structure | Overlay | 0.622 | 0.321 | NEEDS_MORE_EVIDENCE | Regression-only extraction; Fassas-Hourvouliades 2019 reports t-stats, not Sharpe. Keep tracking; promote only when a tradable-strategy SR paper emerges. |
| C004 | M2-vs-BTC macro cointegration | S | 0.502 | 0.035 | NEEDS_MORE_EVIDENCE | Posterior indistinguishable from zero (NUMERIC_MISSING). Sarkar 2025 produces β = 2.65 surrogate only. Re-evaluate when a tradable-SR extension emerges or Gerald backtests internally. |

---

## (d) Stage A.3 rejected candidates — watch list

Not admitted to Stage B because of CITATION_MISSING, EVENT_STUDY_NOT_SHARPE, REDUNDANT, or AMBIGUOUS_SCORE_COMPONENT at Stage A.3. Kept here for monitoring in case a peer-reviewed quantitative paper emerges.

| candidate | rejection reason (Stage A.3) | watch-list note |
|---|---|---|
| MVRV Z-Score | CITATION_MISSING (practitioner origin: Puell, Mahmudov) | Overlaps V019 MVRV/SOPR; itself recommended B→C downgrade. Low priority. |
| NVT Signal 90d (Ferretti-Santoro 2022 NVML attribution) | CITATION_MISSING — attribution could not be verified | Source attribution appears fabricated; do not admit without an independently verifiable citation. |
| Token unlock events (~16,000 events, ~90% negative pressure) | EVENT_STUDY_NOT_SHARPE + CITATION_MISSING | Practitioner (Keyrock, LiquiFi). Event study scale. Route to C-group tracking, not BNMA. |
| Fear & Greed Index < 10 threshold | CITATION_MISSING + NUMERIC_MISSING | n < 10 observations since 2018; statistically underpowered. Track for anecdotal regime-flag use, not BNMA. |
| Short-period RSI (2–5 day) on S&P | CITATION_MISSING | Connors trader literature; no SSRN/NBER peer-reviewed paper with clean Sharpe located. |
| Price-to-sales (tech) | REDUNDANT_WITH_REGISTRY | Value (FF3/FF5) already registered indirectly via V026 residualization. |
| Gold/silver ratio regime | CITATION_MISSING | Only practitioner sources (CME education, IG, Money.com, TradingView). |
| China PMI leading copper | CITATION_MISSING | Becerra 2022 uses MAPE, not Sharpe. Dr. Copper narrative supported but no academic tradable-SR paper. |
| EIA crude inventory surprises | EVENT_STUDY_NOT_SHARPE | C-group catalyst. |
| OPEC+ production decisions | EVENT_STUDY_NOT_SHARPE | C-group catalyst. |
| Market breadth (% constituents > 200-DMA) | CITATION_MISSING | Only practitioner; Schwab, StockCharts, BuildAlpha. Mechanism well-understood but no academic tradable-SR paper. |
| HRP (Hierarchical Risk Parity) | AMBIGUOUS_SCORE_COMPONENT | Portfolio-construction methodology, not a return-predictive signal. Does not map to S/T/R/Overlay. Out of BNMA scope. |

---

## Summary of pipeline actions for 2026-10-14 quarterly

**Promote:**
- **C009 Faber TAA** → Grade B Overlay (formal, meets all three criteria).

**Conditional promote:**
- **C015 Overnight-intraday L/S** → provisional Grade B T, conditional on 6-month paper-trade at ≤ 1% of book and declaration of peer linkage (V033 pre-FOMC drift candidate).

**Downgrade recommendations:**
- **V019 MVRV/SOPR** → Grade B → Grade C (M1 recommendation confirmed by posterior p_pos = 0.59).
- **V005 NFCI** → consider reclassification from Grade A R-variable to non-tradable diagnostic (GRADE_A_BOTTOM3 flag).

**Merge recommendations:**
- **C014 ⊂ C013** → keep one of the crypto perp basis / carry candidates; both overlap.
- **C006, C007 → fold into V014 flow-suite** operational note rather than independent entries.

**Watch through 2027-04:**
- V029 (GEX), V030 (lead-lag), V031 (absorption ratio), V032 (ML feature importance), C004 (M2-BTC), C008 (pairs), C011 (VIX term), C013 (perp carry).

**Registry-maintenance actions (non-audit):**
- V014: split into order-flow vs vol-sort constructs; fix Aloosh-Ouzan-Shahzad 2023 → Aloosh & Li 2024 Mgmt Sci.
- V027: update source citation to AEM 2014 as tradable anchor (keep HKM 2017 as structural).
- V028: correct headline Sharpe to 0.9 (not 1.2–1.5).
- V031: correct journal to JPM (not FAJ) for absorption ratio.
- V015: add Liu-Tsyvinski-Wu 2022 JF as dual-listed primary anchor.
