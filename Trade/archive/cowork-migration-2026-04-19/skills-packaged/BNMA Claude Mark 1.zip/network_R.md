# Stage B — Group R (Risk Overlay) network

**Nodes (K = 8).** V001 VIX, V002 MOVE, V004 HY OAS/EBP, V005 NFCI, V015 BTC realized vol, V016 BTC perp funding, V018 BTC 3m basis, V027 intermediary capital ratio.

**Asset-class anchors.** Cross-Asset (V001, V002, V005, V027), Credit (V004), Crypto (V015, V016, V018).

**Edges (head-to-head pairs).** 0. No Stage A study tests two R variables against each other with comparable tradable Sharpes. All inference is common-scale + asset-class-intercept.

**Peer adjacency (|correlation| ≥ 0.5).**

| node | declared peers | cluster |
|---|---|---|
| V001 | V002, V005 | Cross-asset vol/stress |
| V002 | V001, V005 | Cross-asset vol (bond-specific) |
| V004 | V005, V027 | Credit + dealer capacity |
| V005 | V001, V002, V004 | Composite financial conditions (hub node, highest peer count in R) |
| V015 | — | BTC vol (own market) |
| V016 | V018 | BTC positioning/carry |
| V018 | V016 | BTC positioning/carry |
| V027 | V004 | Dealer balance-sheet (with explicit double-count gate vs V004) |

**Double-count gates.**
- V004 ↔ V027: registry specifies correlation 0.65–0.75 post-2008 and the "take more negative, not sum" aggregation rule. Posterior confirms this is right — head-to-head V004 beats V027 (0.624 vs 0.366), reflecting EBP's tighter construct and longer OOS evidence; V027 should not independently add sizing-down pressure when V004 is already flagging.
- V016 ↔ V018: both BTC crowding measures from different windows (funding = perpetual, basis = quarterly futures). Their p_beats_peers is essentially 50/50 (0.499 / 0.501) because they are near-duplicates with the same posterior; treat them as a single positioning signal, not two independent risk-off votes.

**Study inputs to likelihood (5 total study rows).**

- V001 VIX: 3 studies (Tsai 2025 QF L/S futures 1.70 — LONG_SHORT_FUTURES flag; PMC 2024 C-MVO 0.623; Dai-Wu / Clarke-de Silva-Thorley vol-managed 0.45 — VOL_MANAGED flag). The three studies span distinct constructs; CONSTRUCT_HETEROGENEOUS flag raised.
- V004 HY OAS / EBP: 1 study (Hu 2024 JFE RF bond L/S 3.27 — ML_MULTI_FACTOR flag; EBP is one of many predictors in the ML ensemble, so this Sharpe is not a clean isolated-EBP number)
- V027 Intermediary capital: 1 study (Adrian-Etula-Muir 2014 LMP annualized 1.00 — re-anchored per m3 from HKM 2017 which is non-traded by construction)
- V002, V005, V015, V016, V018: 0 studies — prior-only

**Construct heterogeneity caveat.** V001 VIX carries three distinct operational uses: (i) L/S VIX futures strategy (Tsai), (ii) vol-managed equity overlay (Dai-Wu), (iii) information-ratio minimum-variance portfolio (PMC C-MVO). The pooled posterior 0.72 is not a literal Sharpe for any single use — it is a pooled estimate under construct heterogeneity. For sizing decisions, use the study matching the operational construct, not the pooled mean.

**Effect scale note.** Per v4 spec, R-group effect size is "Sharpe improvement when used as vol-targeting/regime-conditional sizing vs fixed-size baseline, scale ~0.0 to ~0.4". V001 and V004 study inputs are long-short strategy Sharpes (~1.0+), not sizing-improvement deltas. The heterogeneity prior absorbs this scale mismatch, but the posterior is on the raw-Sharpe scale, not the sizing-delta scale. R-group posteriors should therefore be read as "signal quality" rather than literal sizing-improvement deltas.

**Heterogeneity prior.** `tau_k ~ HalfNormal(0.15)` — R/Overlay (compressed scale) per spec. V004 and V001 exceed this threshold (τ_med 0.66 and 0.37 respectively), flagged HETEROGENEOUS in report §3.
