# Stage B — Group S (Structural Directional) network

**Nodes (K = 10).** V003 DXY, V006 UST 2s10s, V007 Real yield/breakevens, V008 ACM term premium, V011 Brent M1-M3 carry, V012 BTC active addresses, V013 BTC hash rate, V019 MVRV/SOPR, V028 basis-momentum, C004 M2-vs-BTC cointegration.

**Asset-class anchors.** Cross-Asset (V003), Rates (V006, V007, V008), Commodities (V011, V028), Crypto (V012, V013, V019, C004). Asset-class intercept `alpha_a ~ N(0, 0.3)` absorbs mean-level differences so that pooling within the group rests on common scale + intercept, not a shared asset-class effect.

**Edges (pairs tested head-to-head in a single study).** Expected 0–3 per v4 spec; Group S has 0 — no Stage A study tests two S variables against each other in a paired horse-race with both Sharpes reported. All inference is therefore common-scale + asset-class-intercept, not indirect evidence chain.

**Peer adjacency (|correlation| ≥ 0.5, from registry + Stage A.5 inference).**

| node | declared peers |
|---|---|
| V003 | — |
| V006 | V007, V008 |
| V007 | V006, V008 |
| V008 | V006, V007 |
| V011 | V028 (dual-use convention: slope + basis-momentum always paired) |
| V012 | V013, V019 (BTC on-chain fundamentals cluster) |
| V013 | V012, V019 |
| V019 | V012, V013 |
| V028 | V011 |
| C004 | — (macro cointegration; no declared peer in S) |

**Study inputs to likelihood (5 total study rows).**

- V011 Brent M1-M3 carry: V011-S1 Fan 2024 JFM (SR 1.12, se 0.14, n=480, TC-inc); V011-S2 Rad-Zaremba 2019 JFIN (SR 0.85, se 0.14, n=360); V011-S3 KMPV 2018 carry (SR 0.74, se 0.09, n=600)
- V028 Basis-Momentum: V028-S1 Boons-Prado 2019 JF headline corrected to 0.90 (se 0.16, n=660); V028-S2 Fan-Zhang 2024 JFM fixed-stop (SR 0.92, se 0.19, n=486). Qian-Jiang-Liu (2024/25) SR *improvement* of 0.13 not added to likelihood — wrong scale.
- All other S variables: prior-only. Posterior = prior, shrunk marginally by asset-class intercept.

**Common-scale caveat (v4 spec wording).** Pooling across Cross-Asset / Rates / Commodities / Crypto within a single Bayesian hierarchy rests on two assumptions: (i) Sharpe is a common effect-size metric across asset classes, (ii) an asset-class intercept can absorb systematic mean differences. Both are defensible for S-group directional signals but are not tested here. The posterior should not be read as a claim of literal equivalence between a 0.79 commodity-carry Sharpe and a 0.79 BTC-addresses Sharpe — the implementation costs, capacity, and construct risk are different even when the posterior number is the same.

**Heterogeneity prior.** `tau_k ~ HalfNormal(0.25)` — S/T scale. Posterior τ_med across S variables ranges 0.14 (V028) to 0.21 (C004); no "unreliable pool" flag raised for any S variable.
