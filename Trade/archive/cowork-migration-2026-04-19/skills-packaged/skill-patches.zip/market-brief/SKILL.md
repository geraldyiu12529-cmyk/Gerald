---
name: market-brief
description: "Produce the daily US pre-open market brief for Gerald's trading workspace. Pulls all Grade A variables via web search, scores the regime, builds the full asset scorecard with S|T|C|R|Sum columns, reads the audit-data staging file for the three audit-addition variables, and writes the markdown brief plus Excel sync. Use this skill whenever the user asks for a 'market brief', 'daily brief', 'pre-open brief', 'regime update', 'pull the numbers', 'refresh the brief', or asks 'what's the market doing'. Also use when the scheduled task `daily-market-brief-8pm-v2` fires. Not for trade recommendations — use the daily-trade-rec skill for those."
---

# Daily Market Brief

Produces the day's US pre-open market brief for Gerald's `/Trade/` workspace. The output is a regime snapshot, a full variable table with Grade A/B readings, and an asset scorecard — the evidence base that the trade-rec skill consumes 25 minutes later.

Local timezone is UTC+8. The canonical slot is 20:00 UTC+8 = 08:00 ET = US pre-open. Use today's local date in the filename. If the file already exists from an earlier run the same day, overwrite and bump the version tag in the title (`v2`, `v3`, …).

---

## Step 1 — Mandatory startup reads

1. `/mnt/.auto-memory/MEMORY.md` — scan index, open relevant memory files
2. `/mnt/Trade/Methodology Prompt.md` — the 8-step framework, Top-28 variable list, evidence grading
3. `/mnt/Trade/Memory.md` — open positions, watchlist (§5), catalysts (§6), lessons (§8)
4. `/mnt/Trade/master-data-log.xlsx` — read the latest row of `RegimeHistory` (prior regime label, growth/inflation/policy/finconditions/riskonoff) and `DailyVariables` (prior variable readings) using openpyxl. These are the authoritative current-state sources.
5. `/mnt/Trade/Data Sources.md` — the variable-to-source mapping with fail-loud rule
6. `/mnt/Trade/Risk Rules.md` — quick scan for any active circuit breaker or heat constraint

If any framework file is missing, stop and surface the gap.

## Step 2 — Read the audit-data staging file

Check for `/mnt/Trade/audit-data-staging-{YYYY-MM-DD}.md` (today's date). This file is produced by the `audit-data-compute-750pm` task at 19:50 — 10 minutes before this brief fires.

- If present: read it and extract the three audit-addition variable values (residual momentum, intermediary capital z-score, basis-momentum). These feed directly into the scorecard.
- If absent: mark all three as `MISSING — staging file not produced` in the variable table. This is correct fail-loud behavior.

## Step 3 — Pull all Grade A variables via web search

For each row in the Minimal Dashboard (Methodology Prompt §3) and the Top-28 variable list, pull the most current reading. Use WebSearch — the sandbox cannot reach FRED/Yahoo/CoinGlass APIs directly.

**Search patterns that reliably return numbers:**

| Variable | Search query | Notes |
|---|---|---|
| VIX | `VIX close today` | CBOE |
| MOVE | `MOVE index today` | Refinitiv |
| DXY | `DXY dollar index close` | ICE |
| HY OAS | `high yield OAS spread FRED BAMLH0A0HYM2` | FRED |
| 2Y/10Y UST | `US 10 year treasury yield today` | DGS2/DGS10 |
| 10Y real yield | `10 year TIPS real yield today` | DFII10 |
| 10Y breakeven | `10 year breakeven inflation rate` | T10YIE |
| Equity prices | `{TICKER} stock price close` | All 12 single-stock + ETFs |
| Brent/WTI | `Brent crude oil price today` | Include curve shape if available |
| Gold/Silver/Copper | `{metal} price today` | |
| BTC/ETH | `Bitcoin price today` | Include funding, basis, flows if found |
| BTC active addresses | `Bitcoin active addresses blockchain.com` | Grade A structural |
| BTC exchange netflows | `Bitcoin exchange netflows CryptoQuant` | Grade A |
| BTC hash rate | `Bitcoin hash rate` | Grade A |
| ETH ETF flows | `Ethereum ETF net flows` | Grade B |
| EURUSD/USDJPY | `EURUSD exchange rate today` | |

**Fail-loud rule:** Any Grade A row from `Data Sources.md` that cannot be pulled must print as `MISSING — [source]`, not `n/a`. The asset's score leg stays blank rather than inferred.

**Time budget:** You have ~20 minutes. Prioritize Grade A variables over Grade B. If a search returns stale data (>2 trading days old), note the date — stale ≠ missing but flag it.

## Step 4 — Score the regime

Using the readings from Steps 2–3, produce the regime snapshot per Methodology Prompt §1:

- Growth: expansion / contraction / ambiguous
- Inflation: disinflation / reflation / stable
- Policy: easing / tightening / on hold; path surprise bias
- Financial conditions: easing / tightening
- Risk-on / risk-off cross-asset state
- BTC vol regime, funding/basis crowding, ETF flow direction

Output: one-line regime label + three primary regime variables being watched.

Compare against the prior regime label (from the latest row in `master-data-log.xlsx` RegimeHistory sheet, read in Step 1). If the label changed, call it out explicitly.

## Step 5 — Build the asset scorecard

For every asset in the universe (Methodology Prompt §0), score S | T | C | R | Sum per Steps 2–6 of the methodology.

**Audit-addition integration (binding):**
- **Equity T (single-stock only):** Use residual momentum from the staging file. If MISSING, leave T blank (fail-loud). Raw TSMOM remains authoritative for ETFs/indices, commodities, FX, crypto.
- **Commodity S:** Use basis-momentum from the staging file. Apply the divergence-cap: if static slope = backwardation (+1) but basis-momentum is flattening, cap S at 0. If MISSING, note it but still score static slope.
- **Cross-asset R:** Use intermediary capital z-score from the staging file. If z < −1σ, downgrade R by one notch on equities, commodities, FX longs. Do not double-count with HY OAS. If MISSING, note the fail-loud caveat.

**Catalyst column (C) is mandatory.** Do not omit it. Score +1 (favorable asymmetry), 0 (no near-term catalyst), or −1 (adverse catalyst). State whether the catalyst is surprise-dependent or confirmation-dependent.

Flag any asset reaching |Sum| ≥ 3 — the trade-rec will evaluate these for entry.

## Step 6 — Variable Discovery Notes

At the end of the brief (after the scorecard, before Memory/Excel updates), add a section:

```
## 6. Variable Discovery Notes

[If nothing observed: "No new variable candidates observed today."]

[If something noticed:]
**Potential candidate:** {Name}
**Observation:** {What you saw, 1-2 sentences}
**Definition:** {Precise definition}
**Mechanism hypothesis:** {Why it might predict}
**Score component:** {S/T/C/R}
**Asset scope:** {Which assets}
**Evidence so far:** {Anecdotal / Weak — be honest}
```

If the observation has been seen 3+ times (check prior briefs), also write a Candidate row to the VariableRegistry sheet in `master-data-log.xlsx` per `Variable-Discovery-Protocol.md` §2.

Do NOT let discovery slow down the brief. This is a lightweight pass — if nothing stands out, write the no-candidate line and move on.

## Step 7 — Write the output file

Path: `/mnt/Trade/market-brief-{YYYY-MM-DD}.md`

Use this section order:

```
# Market Brief — YYYY-MM-DD HH:MM UTC+8 (HH:MM ET, US Pre-Open) — vN

[2–3 line summary of what changed vs prior version, new |Sum| ≥ 3 signals, and count of MISSING Grade A rows]

---

## 1. Regime Snapshot
[Table: Dimension | State | Change vs prior]
Primary regime variables watched: (1)…, (2)…, (3)…

---

## 2. Key Variable Readings
[Table: Bucket | Variable | Reading | Grade | Source / Date]
Grade A MISSING rows: [count] — [list each with which score leg it blocks]

---

## 3. Asset Scorecard
[Table: Asset | S | T | C | R | Sum | Notes]
Highlight any |Sum| ≥ 3 signals.

---

## 4. Watchlist Updates
[Changes to Memory.md §5 — new candidates, removed theses, trigger updates]

---

## 5. Catalyst Calendar (rolling 2 weeks)
[Table: Date | Event | Assets affected | Expectation]

---

## 6. Variable Discovery Notes
[Per Step 6]
```

## Step 8 — Update Memory.md (narrative sections only)

After writing the brief, apply changes to `/mnt/Trade/Memory.md`:

- §5 (Watchlist): update if any thesis was promoted/invalidated by new data
- §6 (Catalysts): refresh the rolling calendar
- §8 (Lessons): append one line: date, brief version, regime label, count of MISSING rows, any material delta vs prior brief

Do not batch — update immediately. Memory is the bridge between sessions.

**Note:** Memory.md §3 (Regime State) and §4 (Key Variables) have been removed. Regime and variable state is maintained exclusively in `master-data-log.xlsx` (RegimeHistory and DailyVariables sheets). Do NOT recreate these sections.

## Step 9 — Sync to master-data-log.xlsx (MANDATORY)

After completing Step 8, read `/mnt/Trade/Excel-Sync-Protocol.md` §1 (market-brief) for the authoritative column mapping, then sync today's data to the workbook using openpyxl.

**Sheets to update:**

1. **DailyVariables** — append one row (or overwrite if today's row exists). Map every variable reading from the brief to the corresponding column using the header row as schema. Key column groups: cross-asset risk (VIX, VIX3M, VIX/VIX3M, MOVE, DXY, HY_OAS, NFCI, Intermediary_Cap_Ratio, Intermediary_Cap_Z), rates (DGS2, DGS10, 2s10s, DFII10, T10YIE, ACM_TP_10Y), equities (SPX, NDX, SPY, QQQ, EWJ, EWY + 12 single stocks + 12 residual momentum columns), commodities (Brent, WTI, Gold, Silver, Copper, Platinum, Palladium + 10 basis-momentum columns), FX (EURUSD, USDJPY), crypto (BTC, ETH, BTC_HashRate, BTC_ActiveAddr, BTC_ExchNetflow, BTC_ETF_Flow, BTC_PerpFunding, BTC_3mBasis, ETH_ETF_Flow, ETH_DailyTxns), meta (GradeA_Missing_Count, Source_Brief).

2. **RegimeHistory** — append one row: Date, Regime_Label, Growth, Inflation, Policy, FinConditions, RiskOnOff, BTC_VolRegime, BTC_FundingBasis, BTC_Structural, Watch_Var_1/2/3, Promoted_Signals, NearMiss_Count, Source_Brief.

3. **DataQuality** — append one row: Date, Total_GradeA_Vars, Missing_Count, Missing_Rate_Pct, Missing_Variables, Stale_Count, Stale_Variables, Audit_ResidMom_Status / Audit_IntCap_Status / Audit_BasisMom_Status (LIVE/MISSING/STALE), Pipeline_Health, Source_Brief, Notes.

4. **CatalystLog** — for each NEW catalyst that doesn't already exist: Date_Added, Catalyst_Date, Event, Assets_Affected, Impact_Level, Expectation, Outcome = PENDING. For passed catalysts, update Outcome if known.

Use `date` objects for dates, `None` for missing values. If a same-day row exists, overwrite and note version in Source_Brief.
