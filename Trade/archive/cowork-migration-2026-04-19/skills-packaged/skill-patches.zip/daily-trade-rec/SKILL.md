---
name: daily-trade-rec
description: Produce a pre-open trade recommendation for Gerald's trading workspace by synthesising the day's market brief, news capture, US close snapshot, and weekly regime review through the 8-step evidence-graded methodology and the binding Risk Rules pre-entry checklist. Automatically logs every promoted and near-miss signal to the SignalLedger sheet in `master-data-log.xlsx` for out-of-sample performance tracking. Use this skill whenever the user asks for a "trade rec", "trade recommendation", "pre-open rec", "daily rec", "trade synthesis", or asks Claude to "run the 8-step", "score the book", or "tell me what to trade today", even if they don't name the file. Also use when the scheduled task `daily-trade-recommendation-820pm-v2` fires. When the user asks to close fail-loud Grade-A data gaps before deciding, this skill also runs the web-search closure pass. Not for generic market commentary — use the market-brief or news-events skills/workflows for those.
---

# Daily Trade Recommendation

Produces the day's pre-open trade rec for Gerald's `/Trade/` workspace. The output is a decision document, not commentary: every section either promotes a trade to entry or explains exactly why it didn't.

Local timezone is UTC+8. The canonical slot is 20:20 UTC+8 = 08:20 ET = US pre-open. Use today's local date in the filename. If the file already exists from an earlier run the same day, overwrite and bump the version tag in the title (`v2`, `v3`, …) so the lineage is auditable.

---

## Step 1 — Mandatory startup reads (in order)

Before any analysis, read all of the following. The first four are framework; the next four are today's upstream evidence and must all be cross-checked.

**Framework:**
1. `/mnt/.auto-memory/MEMORY.md` — scan index, open any relevant memory files
2. `/mnt/Trade/Methodology Prompt.md` — the 8-step framework
3. `/mnt/Trade/Risk Rules.md` — binding pre-entry checklist and sizing policy
4. `/mnt/Trade/Memory.md` — open positions, watchlist, catalysts, lessons
5. `/mnt/Trade/master-data-log.xlsx` — read the latest row of `RegimeHistory` (regime label) and `DailyVariables` (current readings) using openpyxl. Also read all OPEN rows from `SignalLedger` for deduplication in Step 8.

**Today's upstream artifacts (all dated YYYY-MM-DD = today local):**
5. `/mnt/Trade/market-brief-{YYYY-MM-DD}.md` — produced by the 20:00 brief task. Pull regime label, scorecard, levels, catalyst calendar.
6. `/mnt/Trade/news-events/news-{YYYY-MM-DD}.md` — produced by the 20:10 news task. Pull overnight headlines, geopolitics, econ-calendar surprises.
7. `/mnt/Trade/us-close-snapshot-{YYYY-MM-DD}.md` (or most recent prior trading day if today is Mon) — post-close delta from the prior US session.
8. `/mnt/Trade/weekly-review-{most-recent-Sunday}.md` — week's regime trajectory and gating constraints.

If a framework file is missing, stop and surface the gap — do not fabricate the methodology. If an upstream artifact is missing, log it under "Data Gaps" in the output and proceed; do not silently skip. The reason these four upstream files are non-negotiable is that today's recommendation must be reproducible from named, dated source files; if you can't cite where a fact came from, it can't carry a Grade-A claim.

## Step 2 — Build the Upstream Synthesis block

Before scoring anything, produce 5–10 bullets — one per upstream source file — that name the file and the single most decision-relevant fact extracted from it. If two sources conflict, name the conflict and state which you are weighting and why. This block is the first section of the output and is the proof that today's call is grounded in the day's data, not in your memory of yesterday.

## Step 3 — Run the 8-step methodology against every asset in the brief

For each scored asset in the brief's scorecard, confirm or revise S, T, C, R and the aggregate Sum. The brief does the heavy lifting; your job is to (a) check the catalyst column (C) is scored — the methodology mandates it — and (b) apply the correlation gate before promoting anything to entry. If the brief omitted C on a row, score it here before using that row.

**2026-04-14 audit additions that feed into S/T/R (see `Methodology Prompt.md` reconciliation note and Top-25 entries 26–28):**
- **Equity T (single-stock only):** prefer residual momentum (12m FF5-residualized) over raw TSMOM for NVDA/TSLA/AAPL/GOOGL/AMZN/META/TSM/INTC/MU/PYPL/PLTR/WDC. When they disagree, trust residual.
- **Commodity S:** incorporate basis-momentum (4w and 12w change in F1–F2 slope). Divergence-cap rule: if static slope reads +1 but basis-momentum is flattening the curve, cap S at 0.
- **Cross-asset R:** incorporate intermediary capital ratio (NY Fed primary-dealer equity-to-total z-score). If z < −1σ, downgrade R by one notch on equities, commodities, and FX longs. Do not double-count with HY OAS — if both flag stress, take the more negative signal, not their sum.

If any of the three audit-addition data rows are `MISSING`, fail loud in §6 Data Gaps of the output rec and do not infer the leg.

Aggregate Sum thresholds:

| |Sum| | Action |
|---|---|
| ≥ 3 | Candidate for entry — run the pre-entry checklist |
| 2 | Near-miss — enumerate the missing leg in §6 of the output |
| ≤ 1 | Not actionable — omit unless an open position is affected |

## Step 4 — Optional: web-search Grade-A gap closure

If the brief or US close snapshot lists fail-loud Grade-A `MISSING` rows AND the user asked for gap closure (or the missing variable is on a leg that would change a |Sum| = 2 candidate into +3), run a web-search pass to close them before finalising scores. Use WebSearch for human-readable sources; do not rely on FRED/CoinGlass direct fetches (egress-blocked).

Common closures and the search query that works:

| Gap | Search pattern that returns a number | Score leg it unblocks |
|---|---|---|
| DGS2 / DGS10 / DFII10 | `"US 10 year yield" {date}` / `"2-year Treasury yield" {date}` / `10-year TIPS real yield {month YYYY}` | rates block, 2s10s derived, real-yields → Gold S |
| Brent M1–M3 curve slope | `Brent crude M1 M3 futures curve {month YYYY} backwardation contango` | Brent/WTI S confirmation, R unchanged |
| BTC perp funding | `BTC funding rate {date} binance OKX` | BTC R (crowding direction) |
| BTC active addresses | `Bitcoin active addresses {month YYYY} blockchain.com` | BTC S (network usage) |
| META / EURUSD prices | `META stock price close {date}` / `EURUSD exchange rate {date}` | scorecard rows blocked by missing price |
| **Intermediary capital ratio (NY Fed PD equity/total, z-score)** | `NY Fed primary dealer statistics {week-ending-date}` / `"primary dealer" equity capital {month YYYY}` | cross-asset R-overlay leading gate per Methodology Prompt Step 5; do not double-count with HY OAS — take the more negative signal |
| **Residual momentum (equity single-stock)** | `Kenneth French 5-factor monthly {month YYYY}` (pull FF factors, compute residualized 12m return via rolling OLS on stock excess returns) | single-stock T-input per Step 3; applies to NVDA/TSLA/AAPL/GOOGL/AMZN/META/TSM/INTC/MU/PYPL/PLTR/WDC. If raw TSMOM and residual conflict, trust residual. |
| **Basis-momentum (commodities)** | `Brent futures curve settlement {YYYY-MM-DD}` / `WTI CL1 CL2 CL3 futures prices {month YYYY}` — derive F1–F2 slope daily, take 4w / 12w change | commodity S-input per Step 2; divergence-cap rule — if static slope says +1 but basis-momentum shows the curve flattening, cap S at 0 |

Re-score affected legs after each closure. If a closed leg flips a watchlist thesis (e.g., funding negative invalidates a BTC short), update Memory §5 immediately — don't batch.

## Step 5 — Apply the binding pre-entry checklist

Only a candidate that clears **every** item below is eligible for the recommendations table. If any item fails, no trade on that candidate.

1. |Sum| ≥ 3 with C scored (not blank, not "—")
2. Invalidation written, concrete, and date-bounded
3. Correlation gate clean — does this share its primary regime variable with any open position or other simultaneous signal? If yes, treat as an add to that theme and size to the sector cap, not the per-position cap. Canonical example: Copper + Gold + Silver = one reflation/DXY-weak bet, sized once.
4. Per-position risk ≤ 2% AND post-entry portfolio heat ≤ 8%
5. ATR stop set (2–3× for commodities/crypto, 1.5–2× for equities), never fixed %
6. Catalyst asymmetry stated — surprise-dependent vs confirmation-dependent. Surprise-dependent catalysts carry positive convexity and are preferred; confirmation-dependent catalysts where the bar is elevated (e.g. an earnings print already discounted) carry poor asymmetry and usually fail the overall thesis even when scored C+1.

"No trade" is always a valid output. When evidence is mixed or a Grade-A input is `MISSING` on a leg that would decide the call, the correct answer is to say so and wait.

## Step 6 — Write the output file

Path: `/mnt/Trade/trade-rec-{YYYY-MM-DD}.md`. Overwrite if it exists; bump the version tag in the title. Use this exact section order and headings:

```
# Trade Recommendations — YYYY-MM-DD (20:20 UTC+8 = 08:20 ET US pre-open) — vN

## 1. Upstream Synthesis
[5–10 bullets, one per source file, naming the file and the single most decision-relevant fact. Conflicts called out explicitly.]

## 2. Regime Read
[One paragraph. Cite brief + weekly review. State the regime label and the three primary regime variables being watched.]

## 3. Recommendations Table
| Asset | Direction | Entry | Stop | Target | Size | Catalyst | Evidence Grade | Correlation check | Risk-rule check |

If no candidate clears the pre-entry checklist, leave the table empty (one row of "—") and write below it: "No actionable |Sum| ≥ 3 signals today. Pre-entry checklist Risk Rules §7 item 1 fails for every candidate."

## 4. Theses Not Taken (near-misses, |Sum| = 2)
[For each near-miss: name the asset, score legs, the one leg that's missing, and the specific trigger or data that would promote it to +3. One paragraph per candidate. If the missing leg is an audit-addition variable (residual momentum, intermediary capital, basis-momentum), say so explicitly — this is the evidence stream feeding the 2026-10-14 review.]

## 5. Relative-Value Pairs
[Only when the outright regime is mixed AND valuation/carry/revisions rank cleanly. If outright regime aligns across a theme, RV adds no edge — say so and skip.]

## 6. Data Gaps
[Three parts:
  (a) Upstream artifact coverage — name any of the four required artifacts that were missing.
  (b) Audit-addition Grade-A fail-loud rows still MISSING (residual momentum, intermediary capital z, basis-momentum). List each by name and which score leg on which asset it blocks. List these separately from (c) so the 2026-10-14 review can audit visibility.
  (c) Other Grade-A fail-loud rows still MISSING (post-closure if §4 ran). Name each and which score leg it blocks.]

## 7. Pre-Entry Checklist (binding)
[If a trade was taken: walk through items 1–6 with pass/fail.
 If no trade: write "Not applied — no candidate cleared |Sum| ≥ 3 (item 1 fails)." and list items 1–6 for reference.]

## 8. Memory Updates Needed
[Bullet list: positions to log, watchlist changes, invalidated theses. Each item must be concrete enough to act on. Include a dedicated bullet "Audit-addition contribution" when any of the three audit-addition variables moved a scorecard leg into or out of entry range — note the variable, asset, and direction. These are written to the AuditAdditionLog sheet in Step 9.5. If none contributed, write "Audit-addition contribution: no entry today."]

---

Grades cited: A = replicated + coherent mechanism; B = regime-dependent. No Grade C padding. No stock-to-flow / halving-cycle timing.
```

## Step 7 — Apply Memory updates immediately (don't batch)

After writing the rec file, apply every change listed in §8 of the rec to `/mnt/Trade/Memory.md`:

- §5 (Watchlist): mark removals with strikethrough and a one-line reason; add new candidates if a thesis was promoted.
- §2 (Open Positions): add a row only if a |Sum| ≥ 3 candidate cleared the full checklist and an entry was actually taken.
- §8 (Lessons & Corrections): append one line summarising the slot, regime label, signal count, named near-misses, watchlist deltas, and the rec file path with version tag.

**Note:** Memory.md §3 (Regime State), §4 (Key Variables), and §10 (Audit-addition Contribution Log) have been removed. Regime and variable state is maintained in `master-data-log.xlsx` (RegimeHistory, DailyVariables sheets). Audit-addition contributions are written to the `AuditAdditionLog` sheet in Step 9.5 below. Do NOT recreate these Memory sections.

The "don't batch" rule exists because Memory is the bridge between sessions. A change you defer until later is a change that gets lost when the next scheduled run starts.

## Step 8 — Append signals to SignalLedger in master-data-log.xlsx (required, every run)

After writing the rec and applying Memory updates, append every qualifying signal to the **SignalLedger** sheet in `/mnt/Trade/master-data-log.xlsx` using openpyxl. This is the sole out-of-sample performance tracking system — it captures the signal, the scores, and the market price at recommendation time so the `signal-review` skill can later measure whether the system's calls were right.

The reason every run must do this: a performance record is only useful if it's complete. Skipping a day because "nothing happened" creates survivorship bias. Even a "no trade" day with five near-misses at |Sum| = 2 is valuable data.

Read `/mnt/Trade/Excel-Sync-Protocol.md` §2 (daily-trade-rec) for the authoritative column mapping. Key rules:

**For promoted signals** (|Sum| ≥ 3): append one row with ID (next sequential P###), Type='Promoted', Date, Asset, AssetClass, Direction, S/T/C/R/Sum, Entry_Price, ATR_Stop, Target_TP1, Target_TP2, Invalidation, Inv_Date, VIX_at_Entry, Regime_Label, Taken (check Memory.md §2), Status='OPEN'. Exit columns blank.

**For near-miss signals** (|Sum| = 2, or |Sum| ≥ 3 blocked): append one row with ID (next sequential N###), Type='Near-Miss', same score fields, Blocking_Leg, Block_Reason, Price_at_Signal, VIX_at_Signal, Status='OPEN'. Exit columns blank.

**Deduplication rule:** Read all OPEN rows first (done in Step 1). If an asset has an OPEN row with identical S/T/C/R and same blocking leg, skip. If any score changed, append a new row.

**Append-only rule:** Never delete or edit existing rows. If logged incorrectly, add a correction in the Notes column.

**Next ID tracking:** To find the next P### or N### ID, scan the ID column for the max existing number and increment.

---

## Step 9.5 — Sync to master-data-log.xlsx (MANDATORY)

After appending signals in Step 8, also update these sheets per `/mnt/Trade/Excel-Sync-Protocol.md` §2:

1. **AuditAdditionLog** — for each audit-addition variable that moved a scorecard leg today: Date, Variable, Asset, Direction_of_Move, Score_Leg_Before, Score_Leg_After, Impact_on_Sum, Decision_Moving (YES/NO), Source_File. This replaces the former Memory.md §10.

2. **CatalystLog** — update outcomes for any catalysts that resolved since the last rec.

---

## Step 10 — HTML report (required, every run)

Every run produces a single-file HTML report at `/mnt/Trade/report-{YYYY-MM-DD}-trade-rec.html` alongside the `.md` rec. The HTML is the presentation layer; the `.md` remains the source of truth for Memory updates and lineage. Both must ship.

Use Chart.js via CDN (`https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js`) — no external CSS, no other dependencies, so the file renders offline on the user's machine.

**Required section order:**
1. Executive Summary — no-trade verdict or active recommendation, regime label, material changes vs prior runs, catalysts driving the next 48h.
2. Data Collected — sub-sections for cross-asset risk, rates, equities, commodities, crypto. Every cell sourced. **Plus a fixed sub-section "Audit additions (2026-04-14, fail-loud)"** with three rows — residual momentum (12m FF5-residualized) per single-stock name in scope, intermediary capital ratio z-score, basis-momentum (4w and 12w F1–F2 change) per commodity in scope. Each row shows current value or `MISSING`, the source path, and the score leg it feeds. This sub-section must be present every run, even when all three are MISSING — visibility is the point.
3. Analysis Methodology — 8-step table, evidence grading legend, Risk Rules binding constraints, data pipeline note. Include a one-line callout for the 2026-04-14 audit additions: which variable feeds which bucket (residual → equity T, intermediary capital → cross-asset R, basis-momentum → commodity S) with the divergence-cap and double-counting-gate rules named.
4. Discussion — prose interpretation of the day's score changes, correlation gate reasoning, catalyst-window asymmetry. When an audit-addition variable was material to the day's call (either by blocking a near-miss or by binding a score), say so explicitly here in addition to the §1 mention.
5. Results — the scorecards as charts. **For any near-miss whose blocking leg is an audit-addition variable, annotate the score-component stacked bar with a flag** (e.g., a tooltip or label "T blocked: residual-momentum MISSING" or "S capped: basis-momentum divergence"). Without this annotation, a reader can't tell which gaps are blocking the book from acting.
6. Recommendations — no-trade verdict or rec table, watchlist updates, trigger paths for the next 48h, outstanding data gaps, Memory updates persisted this run. **Outstanding data gaps must list audit-addition gaps separately from older Grade-A gaps**, mirroring the §6 (a)/(b)/(c) split in the `.md` rec — so a reader can answer "did the audit additions contribute today?" without grep.

**Required chart inventory (minimum — add more if the day's data warrants):**
- Cross-asset risk dashboard (VIX, MOVE, HY OAS, NFCI, VIX/VIX3M vs stress thresholds)
- UST yield curve (2Y, 10Y)
- 10Y real-yield decomposition (nominal = real + breakeven)
- Brent M1–M3 futures curve shape
- BTC active addresses time series (if active-addr is in play for a score)
- BTC scorecard before/after gap closure (if Step 4 ran)
- Asset aggregate scores bar (full universe subset, sorted)
- Score component stacking (S/T/C/R per asset for near-misses) — with audit-addition annotations on blocked legs as described in §5 above
- Catalyst calendar with reprice-risk bars
- Gap-closure doughnut (closed vs still-MISSING Grade-A rows)
- **Audit-addition status panel** — three small status indicators (residual momentum / intermediary capital / basis-momentum) showing OK / MISSING / contributed-today, with a sparkline from the AuditAdditionLog sheet in master-data-log.xlsx if prior entries exist

Every chart needs a title and axis labels. When a number is illustrative (e.g., Brent belly points where only the front-spread is observed), say so in the chart caption — the user should never mistake an interpolated shape for a measured one.

Why this is mandatory: the `.md` rec is dense and decision-oriented; the HTML report is the auditable visual trail that makes the score logic inspectable at a glance. Without it, a week later no one can quickly see *why* a near-miss was a near-miss or *how close* the gap-closure got the book to actionable. Shipping both forces the analyst (Claude) to reconcile the prose story with the quantitative picture, which catches errors the prose alone would hide. The audit-addition visi