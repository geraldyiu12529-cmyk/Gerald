# install.ps1 — Slack Scheduled Updates skill bundle installer
# Installs four skills into %USERPROFILE%\Documents\Claude\skills\
#   - slack-ingest       (new)
#   - trade-update       (overwrites — adds Slack Layer 5)
#   - market-brief       (overwrites — adds Step 0 Slack ingest)
#   - daily-trade-rec    (overwrites — Slack digest in Step 1 reads)
#
# Existing skills are backed up to skill-backups\YYYY-MM-DD\<name>\ before overwrite.
# Re-run is safe — backup suffix .2, .3, ... avoids clobbering prior backups.

$ErrorActionPreference = 'Stop'

$Skills       = @('slack-ingest','trade-update','market-brief','daily-trade-rec')
$SkillsRoot   = Join-Path $env:USERPROFILE 'Documents\Claude\skills'
$BackupRoot   = Join-Path $env:USERPROFILE 'Documents\Claude\skill-backups'
$Today        = Get-Date -Format 'yyyy-MM-dd'
$BundleDir    = $PSScriptRoot

Write-Host "Slack Scheduled Updates bundle installer"
Write-Host "Target: $SkillsRoot"
Write-Host ""

if (-not (Test-Path $SkillsRoot)) {
    New-Item -ItemType Directory -Path $SkillsRoot -Force | Out-Null
    Write-Host "Created $SkillsRoot"
}

foreach ($skill in $Skills) {
    $src  = Join-Path $BundleDir $skill
    $dest = Join-Path $SkillsRoot $skill

    if (-not (Test-Path $src)) {
        Write-Warning "Source missing: $src — skipping"
        continue
    }

    if (Test-Path $dest) {
        # Back up existing skill — suffix .2, .3... if a backup for today already exists.
        $backupDateDir = Join-Path $BackupRoot $Today
        if (-not (Test-Path $backupDateDir)) {
            New-Item -ItemType Directory -Path $backupDateDir -Force | Out-Null
        }
        $backupDest = Join-Path $backupDateDir $skill
        $n = 2
        while (Test-Path $backupDest) {
            $backupDest = Join-Path $backupDateDir ("{0}.{1}" -f $skill, $n)
            $n++
        }
        Copy-Item -Path $dest -Destination $backupDest -Recurse -Force
        Write-Host "  backed up existing $skill -> $backupDest"
        Remove-Item -Path $dest -Recurse -Force
    }

    Copy-Item -Path $src -Destination $dest -Recurse -Force
    Write-Host "  installed $skill"
}

Write-Host ""
Write-Host "Done. Restart Claude Code (or reload skills) to pick up the new/updated skills."
Write-Host "Backups (if any): $BackupRoot\$Today\"
