---
name: slack-ingest
description: "Pull recent posts from the Slack #trading-scheduled-updates channel and write them to a local digest file for downstream consumption by market-brief and daily-trade-rec. Use for 'ingest slack', 'pull slack updates', 'sync slack'. Also auto-called as Step 0 of /market-brief and /daily-trade-rec."
model: sonnet
allowed-tools: Read Write Bash(python3 *) mcp__3707e784-0d34-4a07-887c-f348b3366436__slack_search_channels mcp__3707e784-0d34-4a07-887c-f348b3366436__slack_read_channel
---

# Slack Ingest

One-way pull: Slack scheduled-agent posts → local `{YYYY-MM-DD}/slack-digest-{date}.md`. Called at the start of the morning pipeline so cloud-produced context (intraday market/news/thesis updates) is folded into local trade decisions.

Local timezone UTC+8. Canonical channel name: `trading-scheduled-updates` (configurable; see Step 1).

---

## Step 1 — Resolve channel ID

```
slack_search_channels(query="trading-scheduled-updates")
```

Pick the exact-name match. If no match: write a digest file with body `CHANNEL NOT FOUND — configure #trading-scheduled-updates and re-run.` and stop. Do not fail-loud silently.

## Step 2 — Pull last 24h of messages

```
slack_read_channel(channel_id=<id>, limit=100, response_format="concise")
```

Filter client-side:
- Keep messages with timestamps within the last 24h (UTC+8 day boundary is fine; cloud agent timestamps are UTC).
- Drop bot system messages (channel_join, etc.).
- Preserve original author, timestamp, and full text.

If >100 messages in the window, paginate via cursor.

## Step 3 — Categorize

Each message is expected to carry a leading tag from the cloud agent:
- `[REGIME]` — regime pulse
- `[NEWS]` — news capture
- `[THESIS]` — thesis-variable delta
- `[POSITION-ALERT]` — positions-monitor flag (stop buffer, catalyst, etc.)
- `[POSITION-STATE]` — **ignore here** (these are snapshots YOU pushed up; no need to ingest back)

Untagged messages go under "Unclassified".

## Step 4 — Write digest

Path: `{YYYY-MM-DD}/slack-digest-{YYYY-MM-DD}.md` where `{YYYY-MM-DD}` is today in UTC+8. Create folder first: `mkdir -p {YYYY-MM-DD}`.

Sections:
```
# Slack Digest — {date} (ingested {ingest-time-utc+8})

Source channel: #trading-scheduled-updates
Window: last 24h ending {ingest-time}

## Regime Pulse
[REGIME-tagged messages, newest first. Each entry: timestamp, one-paragraph body.]

## News
[NEWS-tagged messages.]

## Thesis Variable Deltas
[THESIS-tagged messages.]

## Position Alerts
[POSITION-ALERT messages — these are high priority. Surface at top of digest if any.]

## Unclassified
[Messages without known tags.]
```

If zero messages in window: write a minimal file with body `No scheduled-update posts in last 24h window.` and exit.

## Step 5 — Report

One-line summary: `slack-digest written: N messages across {regime, news, thesis, alert} categories`. Nothing else. This skill is a data-pull, not commentary.

---

## Downstream contract

`/market-brief` Step 1 and `/daily-trade-rec` Step 1 read `{today}/slack-digest-{today}.md` if present. Both skills should treat the digest as optional context (a missing digest is not a fail-loud condition) and cite grades from the digest as **Grade B at best** — it is cloud agent synthesis, not primary source data.
