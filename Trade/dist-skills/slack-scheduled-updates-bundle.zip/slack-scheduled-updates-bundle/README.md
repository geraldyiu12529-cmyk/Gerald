# Slack Scheduled Updates — Skill Bundle

One-click install of the four skills that wire your local trading pipeline to a cloud scheduled agent via `#trading-scheduled-updates`.

## Contents

| Skill | Status | Purpose |
|---|---|---|
| `slack-ingest` | NEW | Pulls the last 24h of scheduled-agent posts into a local `{date}/slack-digest-{date}.md` |
| `trade-update` | OVERWRITE | Adds Layer 5 — posts `[POSITION-STATE]` snapshot to Slack after every trade event |
| `market-brief` | OVERWRITE | Step 0 auto-invokes `/slack-ingest`; digest is item 1 in Step 1 reads |
| `daily-trade-rec` | OVERWRITE | Step 1 reads the digest first, falls back to `/slack-ingest` if brief didn't run |

## Install

Right-click `install.ps1` → **Run with PowerShell**. Or, from PowerShell:

```powershell
cd <folder-containing-this-README>
powershell -ExecutionPolicy Bypass -File .\install.ps1
```

The installer:
1. Creates `%USERPROFILE%\Documents\Claude\skills\` if missing.
2. Backs up any existing `trade-update`, `market-brief`, `daily-trade-rec` to `%USERPROFILE%\Documents\Claude\skill-backups\YYYY-MM-DD\<name>\` (suffix `.2`, `.3` if re-run same day).
3. Copies all four skill folders into the skills directory.

## Post-install

- Reload Claude Code (or restart the client) so it picks up the new/updated skills.
- Confirm the Slack MCP is connected in your Claude Code settings — the two new tool calls are `slack_search_channels`, `slack_read_channel`, and `slack_send_message`.
- Create `#trading-scheduled-updates` in your Slack workspace if it doesn't exist. `slack-ingest` writes a `CHANNEL NOT FOUND` digest instead of silently failing if the channel is missing.

## Rollback

Restore any backed-up skill by copying it back:
```powershell
$date = 'YYYY-MM-DD'  # backup date
Copy-Item "$env:USERPROFILE\Documents\Claude\skill-backups\$date\trade-update" `
          "$env:USERPROFILE\Documents\Claude\skills\trade-update" -Recurse -Force
```
